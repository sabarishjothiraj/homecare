<?php

return [
    'static_otp' => env('STATIC_OTP', '123456'),
    'expiry_minutes' => (int) env('OTP_EXPIRY_MINUTES', 5),
];
