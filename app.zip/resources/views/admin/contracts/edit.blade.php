@extends('layouts.admin')

@section('title', 'Edit Contract')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Edit Contract</h2>
            <p class="text-muted mb-0">Update contract information - {{ $contract->contract_number }}</p>
        </div>
        <a href="{{ route('admin.contracts.show', $contract) }}" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to Contract
        </a>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-file-contract me-2"></i>Contract Information</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.contracts.update', $contract) }}" method="POST" data-ajax="true">
                        @csrf
                        @method('PUT')

                        <div class="row g-3">
                            <!-- Patient Selection -->
                            <div class="col-md-6">
                                <label for="patient_id" class="form-label">
                                    Patient <span class="text-danger">*</span>
                                </label>
                                <select class="form-select @error('patient_id') is-invalid @enderror" 
                                        id="patient_id" 
                                        name="patient_id" 
                                        required>
                                    <option value="">Select Patient</option>
                                    @foreach($patients as $patient)
                                        <option value="{{ $patient->id }}" {{ old('patient_id', $contract->patient_id) == $patient->id ? 'selected' : '' }}>
                                            {{ $patient->name }} - {{ $patient->community }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('patient_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Service Selection -->
                            <div class="col-md-6">
                                <label for="service_id" class="form-label">
                                    Service <span class="text-danger">*</span>
                                </label>
                                <select class="form-select @error('service_id') is-invalid @enderror" 
                                        id="service_id" 
                                        name="service_id" 
                                        required>
                                    <option value="">Select Service</option>
                                    @foreach($services as $service)
                                        <option value="{{ $service->id }}" {{ old('service_id', $contract->service_id) == $service->id ? 'selected' : '' }}>
                                            {{ $service->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('service_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Start Date -->
                            <div class="col-md-6">
                                <label for="start_date" class="form-label">
                                    Start Date <span class="text-danger">*</span>
                                </label>
                                <input type="date" 
                                       class="form-control @error('start_date') is-invalid @enderror" 
                                       id="start_date" 
                                       name="start_date" 
                                       value="{{ old('start_date', $contract->start_date->format('Y-m-d')) }}"
                                       required>
                                @error('start_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Duration Type -->
                            <div class="col-md-6">
                                <label for="duration_type" class="form-label">
                                    Duration Type <span class="text-danger">*</span>
                                </label>
                                <select class="form-select @error('duration_type') is-invalid @enderror"
                                        id="duration_type"
                                        name="duration_type"
                                        required>
                                    <option value="">Select Duration Type</option>
                                    <option value="daily" {{ old('duration_type', $contract->duration_type) === 'daily' ? 'selected' : '' }}>Daily</option>
                                    <option value="weekly" {{ old('duration_type', $contract->duration_type) === 'weekly' ? 'selected' : '' }}>Weekly</option>
                                    <option value="monthly" {{ old('duration_type', $contract->duration_type) === 'monthly' ? 'selected' : '' }}>Monthly</option>
                                    <option value="yearly" {{ old('duration_type', $contract->duration_type) === 'yearly' ? 'selected' : '' }}>Yearly</option>
                                    <option value="custom" {{ old('duration_type', $contract->duration_type) === 'custom' ? 'selected' : '' }}>Custom</option>
                                </select>
                                @error('duration_type')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Duration Value -->
                            <div class="col-md-6" id="duration_value_container">
                                <label for="duration_value" class="form-label">
                                    Duration Value <span class="text-danger" id="duration_required">*</span>
                                </label>
                                <input type="number" 
                                       class="form-control @error('duration_value') is-invalid @enderror" 
                                       id="duration_value" 
                                       name="duration_value" 
                                       value="{{ old('duration_value', $contract->duration_value) }}"
                                       min="1"
                                       placeholder="Enter number of days/months">
                                @error('duration_value')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Amount -->
                            <div class="col-md-6">
                                <label for="amount" class="form-label">
                                    Contract Amount (₹) <span class="text-danger">*</span>
                                </label>
                                <input type="number" 
                                       class="form-control @error('amount') is-invalid @enderror" 
                                       id="amount" 
                                       name="amount" 
                                       value="{{ old('amount', $contract->amount) }}"
                                       min="0"
                                       step="0.01"
                                       required
                                       placeholder="Enter amount">
                                @error('amount')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Payment Method -->
                            <div class="col-md-6">
                                <label for="payment_method" class="form-label">
                                    Payment Method <span class="text-danger">*</span>
                                </label>
                                <select class="form-select @error('payment_method') is-invalid @enderror" 
                                        id="payment_method" 
                                        name="payment_method" 
                                        required>
                                    <option value="">Select Payment Method</option>
                                    <option value="online" {{ old('payment_method', $contract->payment_method) === 'online' ? 'selected' : '' }}>Online</option>
                                    <option value="cash" {{ old('payment_method', $contract->payment_method) === 'cash' ? 'selected' : '' }}>Cash</option>
                                    <option value="cheque" {{ old('payment_method', $contract->payment_method) === 'cheque' ? 'selected' : '' }}>Cheque</option>
                                    <option value="bank_transfer" {{ old('payment_method', $contract->payment_method) === 'bank_transfer' ? 'selected' : '' }}>Bank Transfer</option>
                                </select>
                                @error('payment_method')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Terms and Conditions -->
                            <div class="col-12">
                                <label for="terms" class="form-label">Terms and Conditions</label>
                                <textarea class="form-control @error('terms') is-invalid @enderror" 
                                          id="terms" 
                                          name="terms" 
                                          rows="4"
                                          placeholder="Enter any special terms or conditions for this contract">{{ old('terms', $contract->terms) }}</textarea>
                                @error('terms')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Update Contract
                            </button>
                            <a href="{{ route('admin.contracts.show', $contract) }}" class="btn btn-outline-secondary">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Contract Details</h6>
                </div>
                <div class="card-body">
                    <p class="small mb-2"><strong>Contract Number:</strong> {{ $contract->contract_number }}</p>
                    <p class="small mb-2"><strong>Status:</strong> 
                        @if($contract->status === 'active')
                            <span class="badge bg-success">Active</span>
                        @elseif($contract->status === 'not_assigned')
                            <span class="badge bg-warning">Not Assigned</span>
                        @elseif($contract->status === 'closing_soon')
                            <span class="badge bg-warning">Closing Soon</span>
                        @elseif($contract->status === 'expired')
                            <span class="badge bg-danger">Expired</span>
                        @else
                            <span class="badge bg-secondary">{{ ucfirst($contract->status) }}</span>
                        @endif
                    </p>
                    <p class="small mb-2"><strong>Created:</strong> {{ $contract->created_at->format('M d, Y') }}</p>
                    <p class="small mb-0"><strong>Last Updated:</strong> {{ $contract->updated_at->diffForHumans() }}</p>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Note</h6>
                </div>
                <div class="card-body">
                    <p class="small text-muted mb-0">
                        Updating the contract will recalculate the end date and update the contract status automatically.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const durationTypeSelect = document.getElementById('duration_type');
    const durationValueContainer = document.getElementById('duration_value_container');
    const durationValueInput = document.getElementById('duration_value');

    durationTypeSelect.addEventListener('change', function() {
        if (this.value === 'custom') {
            durationValueInput.value = '';
            durationValueInput.removeAttribute('required');
            durationValueContainer.style.display = 'none';
        } else {
            durationValueInput.setAttribute('required', 'required');
            durationValueContainer.style.display = 'block';
        }
    });

    // Trigger on page load
    if (durationTypeSelect.value === 'custom') {
        durationValueContainer.style.display = 'none';
        durationValueInput.removeAttribute('required');
    }
});
</script>
@endpush
@endsection

