@extends('layouts.admin')

@section('title', 'Contract Details')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">{{ $contract->contract_number }}</h2>
            <p class="text-muted mb-0">Contract Details</p>
        </div>
        <div>
            @if($contract->pdf_path)
                <a href="{{ route('admin.contracts.download', $contract) }}" class="btn btn-success">
                    <i class="fas fa-download me-2"></i>Download PDF
                </a>
            @endif
            @if($contract->status !== 'closed')
                <a href="{{ route('admin.contracts.edit', $contract) }}" class="btn btn-warning">
                    <i class="fas fa-edit me-2"></i>Edit
                </a>
            @endif
            <a href="{{ route('admin.contracts.index') }}" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to List
            </a>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="row g-3">
        <!-- Contract Information -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-file-contract me-2"></i>Contract Information</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="text-muted small">Contract Number</label>
                            <p class="mb-0"><strong>{{ $contract->contract_number }}</strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Status</label>
                            <p class="mb-0">
                                @if($contract->status === 'active')
                                    <span class="badge bg-success">Active</span>
                                @elseif($contract->status === 'not_assigned')
                                    <span class="badge bg-warning">Not Assigned</span>
                                @elseif($contract->status === 'closing_soon')
                                    <span class="badge bg-warning">Closing Soon</span>
                                @elseif($contract->status === 'expired')
                                    <span class="badge bg-danger">Expired</span>
                                @elseif($contract->status === 'closed')
                                    <span class="badge bg-secondary">Closed</span>
                                @else
                                    <span class="badge bg-secondary">{{ ucfirst($contract->status) }}</span>
                                @endif
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Patient</label>
                            <p class="mb-0">
                                <strong>{{ $contract->patient->name ?? 'N/A' }}</strong><br>
                                <small class="text-muted">{{ $contract->patient->community ?? '' }} - {{ $contract->patient->location ?? '' }}</small>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Service</label>
                            <p class="mb-0"><strong>{{ $contract->service->name ?? 'N/A' }}</strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Start Date</label>
                            <p class="mb-0"><strong>{{ $contract->start_date->format('M d, Y') }}</strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">End Date</label>
                            <p class="mb-0">
                                @if($contract->end_date)
                                    <strong>{{ $contract->end_date->format('M d, Y') }}</strong>
                                @else
                                    <span class="badge bg-info">Ongoing</span>
                                @endif
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Duration</label>
                            <p class="mb-0">
                                @if($contract->duration_type === 'custom')
                                    <span class="badge bg-info">Custom</span>
                                @else
                                    <strong>{{ $contract->duration_value }} {{ ucfirst($contract->duration_type) }}</strong>
                                @endif
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Contract Amount</label>
                            <p class="mb-0"><strong class="text-success">₹{{ number_format($contract->amount, 0) }}</strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Payment Method</label>
                            <p class="mb-0"><strong>{{ ucfirst(str_replace('_', ' ', $contract->payment_method)) }}</strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Created</label>
                            <p class="mb-0">{{ $contract->created_at->format('M d, Y h:i A') }}</p>
                        </div>
                        @if($contract->terms)
                            <div class="col-12">
                                <label class="text-muted small">Terms and Conditions</label>
                                <p class="mb-0">{{ $contract->terms }}</p>
                            </div>
                        @endif
                        @if($contract->closure_reason)
                            <div class="col-12">
                                <label class="text-muted small">Closure Reason</label>
                                <p class="mb-0 text-danger">{{ $contract->closure_reason }}</p>
                            </div>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Assignments -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-tasks me-2"></i>Assignments</h5>
                    @if($contract->status !== 'closed' && $contract->status !== 'expired')
                        <a href="{{ route('admin.assignments.create', ['contract_id' => $contract->id]) }}" class="btn btn-sm btn-primary">
                            <i class="fas fa-plus me-1"></i>New Assignment
                        </a>
                    @endif
                </div>
                <div class="card-body p-0">
                    @if($contract->assignments->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Employee</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($contract->assignments as $assignment)
                                    <tr>
                                        <td>
                                            <strong>{{ $assignment->employee->getField('name', 'N/A') }}</strong>
                                            <br>
                                            <small class="text-muted">{{ $assignment->employee->getField('phone', '') }}</small>
                                        </td>
                                        <td>{{ $assignment->start_date->format('M d, Y') }}</td>
                                        <td>{{ $assignment->end_date ? $assignment->end_date->format('M d, Y') : 'Ongoing' }}</td>
                                        <td>
                                            @if($assignment->is_active)
                                                <span class="badge bg-success">Active</span>
                                            @else
                                                <span class="badge bg-secondary">Inactive</span>
                                            @endif
                                        </td>
                                        <td>
                                            <a href="{{ route('admin.assignments.show', $assignment) }}" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <div class="text-center py-4">
                            <i class="fas fa-tasks fa-3x text-muted mb-3 opacity-25"></i>
                            <p class="text-muted">No assignments yet</p>
                            @if($contract->status !== 'closed' && $contract->status !== 'expired')
                                <a href="{{ route('admin.assignments.create', ['contract_id' => $contract->id]) }}" class="btn btn-sm btn-primary">
                                    <i class="fas fa-plus me-1"></i>Create Assignment
                                </a>
                            @endif
                        </div>
                    @endif
                </div>
            </div>

            <!-- Payments -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-money-bill-wave me-2"></i>Payments</h5>
                </div>
                <div class="card-body p-0">
                    @if($contract->payments->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Method</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($contract->payments as $payment)
                                    <tr>
                                        <td>{{ $payment->created_at->format('M d, Y') }}</td>
                                        <td><strong>₹{{ number_format($payment->amount, 0) }}</strong></td>
                                        <td>{{ ucfirst(str_replace('_', ' ', $payment->payment_method)) }}</td>
                                        <td>
                                            <span class="badge bg-success">Paid</span>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <div class="text-center py-4">
                            <i class="fas fa-money-bill-wave fa-3x text-muted mb-3 opacity-25"></i>
                            <p class="text-muted">No payments recorded</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-md-4">
            <!-- Actions Card -->
            @if($contract->status !== 'closed')
                <div class="card border-0 shadow-sm mb-3">
                    <div class="card-header bg-white">
                        <h6 class="mb-0"><i class="fas fa-cog me-2"></i>Actions</h6>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.contracts.regenerate-pdf', $contract) }}" method="POST" class="mb-2">
                            @csrf
                            <button type="submit" class="btn btn-outline-primary w-100">
                                <i class="fas fa-sync me-2"></i>Regenerate PDF
                            </button>
                        </form>
                        
                        @if($contract->status !== 'expired')
                            <button type="button" class="btn btn-outline-danger w-100" data-bs-toggle="modal" data-bs-target="#closeContractModal">
                                <i class="fas fa-times-circle me-2"></i>Close Contract
                            </button>
                        @endif
                    </div>
                </div>
            @endif

            <!-- Patient Info Card -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-user me-2"></i>Patient Information</h6>
                </div>
                <div class="card-body">
                    <p class="small mb-2"><strong>Name:</strong> {{ $contract->patient->name ?? 'N/A' }}</p>
                    <p class="small mb-2"><strong>Phone:</strong> {{ $contract->patient->phone ?? 'N/A' }}</p>
                    <p class="small mb-2"><strong>Email:</strong> {{ $contract->patient->email ?? 'N/A' }}</p>
                    <p class="small mb-0"><strong>Location:</strong> {{ $contract->patient->location ?? 'N/A' }}</p>
                    <a href="{{ route('admin.patients.show', $contract->patient) }}" class="btn btn-sm btn-outline-primary w-100 mt-3">
                        View Patient Details
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Close Contract Modal -->
@if($contract->status !== 'closed' && $contract->status !== 'expired')
<div class="modal fade" id="closeContractModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.contracts.close', $contract) }}" method="POST">
                @csrf
                @method('PATCH')
                <div class="modal-header">
                    <h5 class="modal-title">Close Contract</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        This action will close the contract and end all active assignments.
                    </div>
                    <div class="mb-3">
                        <label for="closure_reason" class="form-label">Closure Reason <span class="text-danger">*</span></label>
                        <textarea class="form-control" id="closure_reason" name="closure_reason" rows="3" required placeholder="Enter reason for closing this contract"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Close Contract</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endif
@endsection

