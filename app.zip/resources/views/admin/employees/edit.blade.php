@extends('layouts.admin')

@section('title', 'Edit Employee')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Edit Employee</h2>
            <p class="text-muted mb-0">Update employee information</p>
        </div>
        <a href="{{ route('admin.employees.show', $employee) }}" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to Employee
        </a>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-user-nurse me-2"></i>Employee Information</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.employees.update', $employee) }}" method="POST" enctype="multipart/form-data" data-ajax="true">
                        @csrf
                        @method('PUT')

                        <div class="row g-3">
                            @foreach($fields as $field)
                                @if(!$field->is_document)
                                    <div class="col-md-{{ $field->type === 'textarea' ? '12' : '6' }}">
                                        <label for="{{ $field->name }}" class="form-label">
                                            {{ $field->label }}
                                            @if($field->is_required)
                                                <span class="text-danger">*</span>
                                            @endif
                                        </label>

                                        @if($field->type === 'text' || $field->type === 'email' || $field->type === 'number')
                                            <input type="{{ $field->type }}"
                                                   class="form-control @error($field->name) is-invalid @enderror"
                                                   id="{{ $field->name }}"
                                                   name="{{ $field->name }}"
                                                   value="{{ old($field->name, $employee->getField($field->name)) }}"
                                                   {{ $field->is_required ? 'required' : '' }}
                                                   maxlength="255">
                                        @elseif($field->type === 'date')
                                            <input type="date"
                                                   class="form-control @error($field->name) is-invalid @enderror"
                                                   id="{{ $field->name }}"
                                                   name="{{ $field->name }}"
                                                   value="{{ old($field->name, $employee->getField($field->name)) }}"
                                                   {{ $field->is_required ? 'required' : '' }}>
                                        @elseif($field->type === 'textarea')
                                            <textarea class="form-control @error($field->name) is-invalid @enderror"
                                                      id="{{ $field->name }}"
                                                      name="{{ $field->name }}"
                                                      rows="3"
                                                      {{ $field->is_required ? 'required' : '' }}
                                                      maxlength="1000">{{ old($field->name, $employee->getField($field->name)) }}</textarea>
                                        @elseif($field->type === 'select')
                                            <select class="form-select @error($field->name) is-invalid @enderror" 
                                                    id="{{ $field->name }}" 
                                                    name="{{ $field->name }}"
                                                    {{ $field->is_required ? 'required' : '' }}>
                                                <option value="">Select {{ $field->label }}</option>
                                                @if($field->options)
                                                    @foreach($field->options as $option)
                                                        <option value="{{ $option }}" 
                                                            {{ old($field->name, $employee->getField($field->name)) === $option ? 'selected' : '' }}>
                                                            {{ $option }}
                                                        </option>
                                                    @endforeach
                                                @endif
                                            </select>
                                        @endif

                                        @error($field->name)
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                @endif
                            @endforeach

                            <!-- Caste -->
                            <div class="col-md-6">
                                <label for="caste_id" class="form-label">Caste</label>
                                <select class="form-select @error('caste_id') is-invalid @enderror"
                                        id="caste_id"
                                        name="caste_id">
                                    <option value="">Select Caste</option>
                                    @foreach($castes as $caste)
                                        <option value="{{ $caste->id }}" {{ old('caste_id', $employee->caste_id) == $caste->id ? 'selected' : '' }}>
                                            {{ $caste->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('caste_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Subcaste -->
                            <div class="col-md-6">
                                <label for="subcaste" class="form-label">Subcaste</label>
                                <input type="text"
                                       class="form-control @error('subcaste') is-invalid @enderror"
                                       id="subcaste"
                                       name="subcaste"
                                       value="{{ old('subcaste', $employee->subcaste) }}"
                                       maxlength="100">
                                @error('subcaste')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <!-- Document Uploads -->
                        @php
                            $documentFields = $fields->where('is_document', true);
                        @endphp

                        @if($documentFields->count() > 0)
                            <hr class="my-4">
                            <h6 class="mb-3"><i class="fas fa-file-upload me-2"></i>Documents</h6>
                            <div class="row g-3">
                                @foreach($documentFields as $field)
                                    <div class="col-md-6">
                                        <label for="{{ $field->name }}" class="form-label">
                                            {{ $field->label }}
                                        </label>
                                        
                                        @php
                                            $existingDoc = $employee->documents->where('field_id', $field->id)->first();
                                        @endphp
                                        
                                        @if($existingDoc)
                                            <div class="mb-2">
                                                <a href="{{ Storage::url($existingDoc->file_path) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-file me-1"></i>{{ $existingDoc->file_name }}
                                                </a>
                                            </div>
                                        @endif
                                        
                                        <input type="file" 
                                               class="form-control @error($field->name) is-invalid @enderror" 
                                               id="{{ $field->name }}" 
                                               name="{{ $field->name }}"
                                               accept=".pdf,.jpg,.jpeg,.png">
                                        <small class="text-muted">Upload new file to replace existing</small>
                                        @error($field->name)
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                @endforeach
                            </div>
                        @endif

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Update Employee
                            </button>
                            <a href="{{ route('admin.employees.show', $employee) }}" class="btn btn-outline-secondary">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Employee Details</h6>
                </div>
                <div class="card-body">
                    <p class="small mb-2"><strong>Status:</strong> 
                        @if($employee->status === 'active')
                            <span class="badge bg-success">Active</span>
                        @elseif($employee->status === 'pending')
                            <span class="badge bg-warning">Pending</span>
                        @else
                            <span class="badge bg-secondary">Inactive</span>
                        @endif
                    </p>
                    <p class="small mb-2"><strong>Created:</strong> {{ $employee->created_at->format('M d, Y') }}</p>
                    <p class="small mb-0"><strong>Last Updated:</strong> {{ $employee->updated_at->diffForHumans() }}</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

