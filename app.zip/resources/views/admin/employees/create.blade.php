@extends('layouts.admin')

@section('title', 'Add New Employee')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Add New Employee</h2>
            <p class="text-muted mb-0">Create a new employee record</p>
        </div>
        <a href="{{ route('admin.employees.index') }}" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to Employees
        </a>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-user-nurse me-2"></i>Employee Information</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.employees.store') }}" method="POST" enctype="multipart/form-data" data-ajax="true">
                        @csrf

                        <div class="row g-3">
                            @foreach($fields as $field)
                                @if(!$field->is_document)
                                    <div class="col-md-{{ $field->type === 'textarea' ? '12' : '6' }}">
                                        <label for="{{ $field->name }}" class="form-label">
                                            {{ $field->label }}
                                            @if($field->is_required)
                                                <span class="text-danger">*</span>
                                            @endif
                                        </label>

                                        @if($field->type === 'text' || $field->type === 'email' || $field->type === 'number')
                                            <input type="{{ $field->type }}"
                                                   class="form-control @error($field->name) is-invalid @enderror"
                                                   id="{{ $field->name }}"
                                                   name="{{ $field->name }}"
                                                   value="{{ old($field->name) }}"
                                                   {{ $field->is_required ? 'required' : '' }}
                                                   maxlength="255">
                                        @elseif($field->type === 'date')
                                            <input type="date"
                                                   class="form-control @error($field->name) is-invalid @enderror"
                                                   id="{{ $field->name }}"
                                                   name="{{ $field->name }}"
                                                   value="{{ old($field->name) }}"
                                                   {{ $field->is_required ? 'required' : '' }}>
                                        @elseif($field->type === 'textarea')
                                            <textarea class="form-control @error($field->name) is-invalid @enderror"
                                                      id="{{ $field->name }}"
                                                      name="{{ $field->name }}"
                                                      rows="3"
                                                      {{ $field->is_required ? 'required' : '' }}
                                                      maxlength="1000">{{ old($field->name) }}</textarea>
                                        @elseif($field->type === 'select')
                                            <select class="form-select @error($field->name) is-invalid @enderror" 
                                                    id="{{ $field->name }}" 
                                                    name="{{ $field->name }}"
                                                    {{ $field->is_required ? 'required' : '' }}>
                                                <option value="">Select {{ $field->label }}</option>
                                                @if($field->options)
                                                    @foreach($field->options as $option)
                                                        <option value="{{ $option }}" {{ old($field->name) === $option ? 'selected' : '' }}>
                                                            {{ $option }}
                                                        </option>
                                                    @endforeach
                                                @endif
                                            </select>
                                        @endif

                                        @error($field->name)
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                @endif
                            @endforeach

                            <!-- Caste -->
                            <div class="col-md-6">
                                <label for="caste_id" class="form-label">Caste</label>
                                <select class="form-select @error('caste_id') is-invalid @enderror"
                                        id="caste_id"
                                        name="caste_id">
                                    <option value="">Select Caste</option>
                                    @foreach($castes as $caste)
                                        <option value="{{ $caste->id }}" {{ old('caste_id') == $caste->id ? 'selected' : '' }}>
                                            {{ $caste->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('caste_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Subcaste -->
                            <div class="col-md-6">
                                <label for="subcaste" class="form-label">Subcaste</label>
                                <input type="text"
                                       class="form-control @error('subcaste') is-invalid @enderror"
                                       id="subcaste"
                                       name="subcaste"
                                       value="{{ old('subcaste') }}"
                                       maxlength="100">
                                @error('subcaste')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <!-- Document Uploads -->
                        @php
                            $documentFields = $fields->where('is_document', true);
                        @endphp

                        @if($documentFields->count() > 0)
                            <hr class="my-4">
                            <h6 class="mb-3"><i class="fas fa-file-upload me-2"></i>Documents</h6>
                            <div class="row g-3">
                                @foreach($documentFields as $field)
                                    <div class="col-md-6">
                                        <label for="{{ $field->name }}" class="form-label">
                                            {{ $field->label }}
                                            @if($field->is_required)
                                                <span class="text-danger">*</span>
                                            @endif
                                        </label>
                                        <input type="file" 
                                               class="form-control @error($field->name) is-invalid @enderror" 
                                               id="{{ $field->name }}" 
                                               name="{{ $field->name }}"
                                               accept=".pdf,.jpg,.jpeg,.png"
                                               {{ $field->is_required ? 'required' : '' }}>
                                        <small class="text-muted">Accepted: PDF, JPG, PNG (Max 5MB)</small>
                                        @error($field->name)
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                @endforeach
                            </div>
                        @endif

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Create Employee
                            </button>
                            <a href="{{ route('admin.employees.index') }}" class="btn btn-outline-secondary">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Information</h6>
                </div>
                <div class="card-body">
                    <p class="small text-muted mb-2">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        Required fields are marked with <span class="text-danger">*</span>
                    </p>
                    <p class="small text-muted mb-2">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        New employees will have "Pending" status
                    </p>
                    <p class="small text-muted mb-2">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        Upload all required documents
                    </p>
                    <p class="small text-muted mb-0">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        Activate employee after verification
                    </p>
                </div>
            </div>

            @if($fields->count() === 0)
                <div class="alert alert-warning mt-3">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>No fields configured!</strong><br>
                    Please configure employee fields first.
                    <a href="{{ route('admin.employee-fields.index') }}" class="alert-link">Configure Fields</a>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection

