@extends('layouts.admin')

@section('title', 'Assignment Details')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Assignment #{{ $assignment->id }}</h2>
            <p class="text-muted mb-0">Assignment Details</p>
        </div>
        <div>
            @if($assignment->is_active)
                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#emergencyReplaceModal">
                    <i class="fas fa-exchange-alt me-2"></i>Emergency Replace
                </button>
            @endif
            <a href="{{ route('admin.assignments.edit', $assignment) }}" class="btn btn-warning">
                <i class="fas fa-edit me-2"></i>Edit
            </a>
            <a href="{{ route('admin.assignments.index') }}" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to List
            </a>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="row g-3">
        <!-- Assignment Information -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-tasks me-2"></i>Assignment Information</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="text-muted small">Assignment ID</label>
                            <p class="mb-0"><strong>#{{ $assignment->id }}</strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Status</label>
                            <p class="mb-0">
                                @if($assignment->is_active)
                                    <span class="badge bg-success">Active</span>
                                @else
                                    <span class="badge bg-secondary">Inactive</span>
                                @endif
                                @if($assignment->is_emergency_replacement)
                                    <span class="badge bg-danger ms-1">Emergency Replacement</span>
                                @endif
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Start Date</label>
                            <p class="mb-0"><strong>{{ $assignment->start_date->format('M d, Y') }}</strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">End Date</label>
                            <p class="mb-0">
                                @if($assignment->end_date)
                                    <strong>{{ $assignment->end_date->format('M d, Y') }}</strong>
                                @else
                                    <span class="badge bg-info">Ongoing</span>
                                @endif
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Duration</label>
                            <p class="mb-0">
                                @if($assignment->end_date)
                                    {{ $assignment->start_date->diffInDays($assignment->end_date) }} days
                                @else
                                    {{ $assignment->start_date->diffInDays(now()) }} days (ongoing)
                                @endif
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Created</label>
                            <p class="mb-0">{{ $assignment->created_at->format('M d, Y h:i A') }}</p>
                        </div>
                        @if($assignment->notes)
                            <div class="col-12">
                                <label class="text-muted small">Notes</label>
                                <p class="mb-0">{{ $assignment->notes }}</p>
                            </div>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Contract Information -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-file-contract me-2"></i>Contract Information</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="text-muted small">Contract Number</label>
                            <p class="mb-0">
                                <strong class="text-primary">{{ $assignment->contract->contract_number ?? 'N/A' }}</strong>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Contract Status</label>
                            <p class="mb-0">
                                @if($assignment->contract->status === 'active')
                                    <span class="badge bg-success">Active</span>
                                @elseif($assignment->contract->status === 'not_assigned')
                                    <span class="badge bg-warning">Not Assigned</span>
                                @elseif($assignment->contract->status === 'closing_soon')
                                    <span class="badge bg-warning">Closing Soon</span>
                                @elseif($assignment->contract->status === 'expired')
                                    <span class="badge bg-danger">Expired</span>
                                @elseif($assignment->contract->status === 'closed')
                                    <span class="badge bg-secondary">Closed</span>
                                @else
                                    <span class="badge bg-secondary">{{ ucfirst($assignment->contract->status) }}</span>
                                @endif
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Service</label>
                            <p class="mb-0"><strong>{{ $assignment->contract->service->name ?? 'N/A' }}</strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Contract Amount</label>
                            <p class="mb-0"><strong class="text-success">₹{{ number_format($assignment->contract->amount, 0) }}</strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Contract Period</label>
                            <p class="mb-0">
                                {{ $assignment->contract->start_date->format('M d, Y') }} - 
                                {{ $assignment->contract->end_date ? $assignment->contract->end_date->format('M d, Y') : 'Ongoing' }}
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Payment Method</label>
                            <p class="mb-0">{{ ucfirst(str_replace('_', ' ', $assignment->contract->payment_method)) }}</p>
                        </div>
                        <div class="col-12">
                            <a href="{{ route('admin.contracts.show', $assignment->contract) }}" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-eye me-1"></i>View Full Contract
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Patient Information -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-user me-2"></i>Patient Information</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="text-muted small">Name</label>
                            <p class="mb-0"><strong>{{ $assignment->contract->patient->name ?? 'N/A' }}</strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Phone</label>
                            <p class="mb-0">{{ $assignment->contract->patient->phone ?? 'N/A' }}</p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Community</label>
                            <p class="mb-0">{{ $assignment->contract->patient->community ?? 'N/A' }}</p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Location</label>
                            <p class="mb-0">{{ $assignment->contract->patient->location ?? 'N/A' }}</p>
                        </div>
                        <div class="col-12">
                            <label class="text-muted small">Address</label>
                            <p class="mb-0">{{ $assignment->contract->patient->address ?? 'N/A' }}</p>
                        </div>
                        <div class="col-12">
                            <a href="{{ route('admin.patients.show', $assignment->contract->patient) }}" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-eye me-1"></i>View Patient Details
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Employee Information -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-user-nurse me-2"></i>Employee Information</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="text-muted small">Name</label>
                            <p class="mb-0"><strong>{{ $assignment->employee->getField('name', 'N/A') }}</strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Phone</label>
                            <p class="mb-0">{{ $assignment->employee->getField('phone', 'N/A') }}</p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Email</label>
                            <p class="mb-0">{{ $assignment->employee->getField('email', 'N/A') }}</p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Employee Status</label>
                            <p class="mb-0">
                                @if($assignment->employee->status === 'active')
                                    <span class="badge bg-success">Active</span>
                                @elseif($assignment->employee->status === 'pending')
                                    <span class="badge bg-warning">Pending</span>
                                @else
                                    <span class="badge bg-secondary">Inactive</span>
                                @endif
                            </p>
                        </div>
                        <div class="col-12">
                            <a href="{{ route('admin.employees.show', $assignment->employee) }}" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-eye me-1"></i>View Employee Details
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-md-4">
            <!-- Quick Actions -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-cog me-2"></i>Quick Actions</h6>
                </div>
                <div class="card-body">
                    <a href="{{ route('admin.assignments.edit', $assignment) }}" class="btn btn-outline-warning w-100 mb-2">
                        <i class="fas fa-edit me-2"></i>Edit Assignment
                    </a>
                    @if($assignment->is_active)
                        <button type="button" class="btn btn-outline-warning w-100 mb-2" data-bs-toggle="modal" data-bs-target="#emergencyReplaceModal">
                            <i class="fas fa-exchange-alt me-2"></i>Emergency Replace
                        </button>
                    @endif
                    <form action="{{ route('admin.assignments.destroy', $assignment) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this assignment?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-outline-danger w-100">
                            <i class="fas fa-trash me-2"></i>Delete Assignment
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Emergency Replace Modal -->
@if($assignment->is_active)
<div class="modal fade" id="emergencyReplaceModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.assignments.emergency-replace', $assignment) }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Emergency Replacement</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        This will immediately end the current assignment and create a new emergency assignment.
                    </div>
                    <div class="mb-3">
                        <label for="employee_id" class="form-label">New Employee <span class="text-danger">*</span></label>
                        <select class="form-select" id="employee_id" name="employee_id" required>
                            <option value="">Select Employee</option>
                            @foreach(\App\Models\Employee::active()->get() as $employee)
                                @if($employee->id !== $assignment->employee_id)
                                    <option value="{{ $employee->id }}">
                                        {{ $employee->getField('name', 'Employee #' . $employee->id) }}
                                    </option>
                                @endif
                            @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="notes" class="form-label">Reason for Replacement</label>
                        <textarea class="form-control" id="notes" name="notes" rows="3" placeholder="Enter reason for emergency replacement"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">Replace Employee</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endif
@endsection

