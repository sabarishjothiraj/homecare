@extends('layouts.admin')

@section('title', 'Create New Assignment')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Create New Assignment</h2>
            <p class="text-muted mb-0">Assign an employee to a contract</p>
        </div>
        <a href="{{ route('admin.assignments.index') }}" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to Assignments
        </a>
    </div>

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="row">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-tasks me-2"></i>Assignment Information</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.assignments.store') }}" method="POST" data-ajax="true">
                        @csrf

                        <div class="row g-3">
                            <!-- Contract Selection -->
                            <div class="col-md-6">
                                <label for="contract_id" class="form-label">
                                    Contract <span class="text-danger">*</span>
                                </label>
                                <select class="form-select @error('contract_id') is-invalid @enderror" 
                                        id="contract_id" 
                                        name="contract_id" 
                                        required>
                                    <option value="">Select Contract</option>
                                    @foreach($contracts as $contract)
                                        <option value="{{ $contract->id }}" 
                                            {{ old('contract_id', $contractId) == $contract->id ? 'selected' : '' }}
                                            data-patient="{{ $contract->patient->name ?? 'N/A' }}"
                                            data-service="{{ $contract->service->name ?? 'N/A' }}"
                                            data-amount="{{ number_format($contract->amount, 0) }}">
                                            {{ $contract->contract_number }} - {{ $contract->patient->name ?? 'N/A' }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('contract_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <div id="contract-info" class="mt-2 small text-muted"></div>
                            </div>

                            <!-- Employee Selection -->
                            <div class="col-md-6">
                                <label for="employee_id" class="form-label">
                                    Employee <span class="text-danger">*</span>
                                </label>
                                <select class="form-select @error('employee_id') is-invalid @enderror" 
                                        id="employee_id" 
                                        name="employee_id" 
                                        required>
                                    <option value="">Select Employee</option>
                                    @foreach($employees as $employee)
                                        <option value="{{ $employee->id }}" {{ old('employee_id') == $employee->id ? 'selected' : '' }}>
                                            {{ $employee->getField('name', 'Employee #' . $employee->id) }}
                                            @if($employee->getField('phone'))
                                                - {{ $employee->getField('phone') }}
                                            @endif
                                        </option>
                                    @endforeach
                                </select>
                                @error('employee_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Start Date -->
                            <div class="col-md-6">
                                <label for="start_date" class="form-label">
                                    Start Date <span class="text-danger">*</span>
                                </label>
                                <input type="date" 
                                       class="form-control @error('start_date') is-invalid @enderror" 
                                       id="start_date" 
                                       name="start_date" 
                                       value="{{ old('start_date', date('Y-m-d')) }}"
                                       required>
                                @error('start_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- End Date -->
                            <div class="col-md-6">
                                <label for="end_date" class="form-label">
                                    End Date <small class="text-muted">(Optional - leave blank for ongoing)</small>
                                </label>
                                <input type="date" 
                                       class="form-control @error('end_date') is-invalid @enderror" 
                                       id="end_date" 
                                       name="end_date" 
                                       value="{{ old('end_date') }}">
                                @error('end_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Emergency Replacement Checkbox -->
                            <div class="col-12">
                                <div class="form-check">
                                    <input class="form-check-input" 
                                           type="checkbox" 
                                           id="is_emergency_replacement" 
                                           name="is_emergency_replacement"
                                           {{ old('is_emergency_replacement') ? 'checked' : '' }}>
                                    <label class="form-check-label" for="is_emergency_replacement">
                                        <strong>Emergency Replacement</strong>
                                        <small class="text-muted d-block">Check this if this is an emergency replacement assignment</small>
                                    </label>
                                </div>
                            </div>

                            <!-- Notes -->
                            <div class="col-12">
                                <label for="notes" class="form-label">Notes</label>
                                <textarea class="form-control @error('notes') is-invalid @enderror" 
                                          id="notes" 
                                          name="notes" 
                                          rows="3"
                                          placeholder="Enter any special notes or instructions for this assignment">{{ old('notes') }}</textarea>
                                @error('notes')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Create Assignment
                            </button>
                            <a href="{{ route('admin.assignments.index') }}" class="btn btn-outline-secondary">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Information</h6>
                </div>
                <div class="card-body">
                    <p class="small text-muted mb-2">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        Required fields are marked with <span class="text-danger">*</span>
                    </p>
                    <p class="small text-muted mb-2">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        Only active employees can be assigned
                    </p>
                    <p class="small text-muted mb-2">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        Previous active assignment will be deactivated
                    </p>
                    <p class="small text-muted mb-0">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        Contract status will be updated automatically
                    </p>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Note</h6>
                </div>
                <div class="card-body">
                    <p class="small text-muted mb-0">
                        Creating a new assignment will automatically deactivate any existing active assignment for the selected contract.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const contractSelect = document.getElementById('contract_id');
    const contractInfo = document.getElementById('contract-info');

    contractSelect.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        if (selectedOption.value) {
            const patient = selectedOption.getAttribute('data-patient');
            const service = selectedOption.getAttribute('data-service');
            const amount = selectedOption.getAttribute('data-amount');
            
            contractInfo.innerHTML = `
                <strong>Patient:</strong> ${patient} | 
                <strong>Service:</strong> ${service} | 
                <strong>Amount:</strong> ₹${amount}
            `;
        } else {
            contractInfo.innerHTML = '';
        }
    });

    // Trigger on page load if contract is pre-selected
    if (contractSelect.value) {
        contractSelect.dispatchEvent(new Event('change'));
    }
});
</script>
@endpush
@endsection

