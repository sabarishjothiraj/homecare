@extends('layouts.admin')

@section('title', 'Edit Assignment')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Edit Assignment</h2>
            <p class="text-muted mb-0">Update assignment information - Assignment #{{ $assignment->id }}</p>
        </div>
        <a href="{{ route('admin.assignments.show', $assignment) }}" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to Assignment
        </a>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-tasks me-2"></i>Assignment Information</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.assignments.update', $assignment) }}" method="POST" data-ajax="true">
                        @csrf
                        @method('PUT')

                        <div class="row g-3">
                            <!-- Contract (Read-only) -->
                            <div class="col-md-6">
                                <label class="form-label">Contract</label>
                                <input type="text" 
                                       class="form-control" 
                                       value="{{ $assignment->contract->contract_number ?? 'N/A' }} - {{ $assignment->contract->patient->name ?? 'N/A' }}"
                                       readonly>
                                <small class="text-muted">Contract cannot be changed after assignment creation</small>
                            </div>

                            <!-- Employee Selection -->
                            <div class="col-md-6">
                                <label for="employee_id" class="form-label">
                                    Employee <span class="text-danger">*</span>
                                </label>
                                <select class="form-select @error('employee_id') is-invalid @enderror" 
                                        id="employee_id" 
                                        name="employee_id" 
                                        required>
                                    <option value="">Select Employee</option>
                                    @foreach($employees as $employee)
                                        <option value="{{ $employee->id }}" {{ old('employee_id', $assignment->employee_id) == $employee->id ? 'selected' : '' }}>
                                            {{ $employee->getField('name', 'Employee #' . $employee->id) }}
                                            @if($employee->getField('phone'))
                                                - {{ $employee->getField('phone') }}
                                            @endif
                                        </option>
                                    @endforeach
                                </select>
                                @error('employee_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Start Date -->
                            <div class="col-md-6">
                                <label for="start_date" class="form-label">
                                    Start Date <span class="text-danger">*</span>
                                </label>
                                <input type="date" 
                                       class="form-control @error('start_date') is-invalid @enderror" 
                                       id="start_date" 
                                       name="start_date" 
                                       value="{{ old('start_date', $assignment->start_date->format('Y-m-d')) }}"
                                       required>
                                @error('start_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- End Date -->
                            <div class="col-md-6">
                                <label for="end_date" class="form-label">
                                    End Date <small class="text-muted">(Optional - leave blank for ongoing)</small>
                                </label>
                                <input type="date" 
                                       class="form-control @error('end_date') is-invalid @enderror" 
                                       id="end_date" 
                                       name="end_date" 
                                       value="{{ old('end_date', $assignment->end_date ? $assignment->end_date->format('Y-m-d') : '') }}">
                                @error('end_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Active Status Checkbox -->
                            <div class="col-12">
                                <div class="form-check">
                                    <input class="form-check-input" 
                                           type="checkbox" 
                                           id="is_active" 
                                           name="is_active"
                                           {{ old('is_active', $assignment->is_active) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="is_active">
                                        <strong>Active Assignment</strong>
                                        <small class="text-muted d-block">Uncheck to deactivate this assignment</small>
                                    </label>
                                </div>
                            </div>

                            <!-- Notes -->
                            <div class="col-12">
                                <label for="notes" class="form-label">Notes</label>
                                <textarea class="form-control @error('notes') is-invalid @enderror" 
                                          id="notes" 
                                          name="notes" 
                                          rows="3"
                                          placeholder="Enter any special notes or instructions for this assignment">{{ old('notes', $assignment->notes) }}</textarea>
                                @error('notes')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Update Assignment
                            </button>
                            <a href="{{ route('admin.assignments.show', $assignment) }}" class="btn btn-outline-secondary">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Assignment Details</h6>
                </div>
                <div class="card-body">
                    <p class="small mb-2"><strong>Assignment ID:</strong> #{{ $assignment->id }}</p>
                    <p class="small mb-2"><strong>Contract:</strong> {{ $assignment->contract->contract_number ?? 'N/A' }}</p>
                    <p class="small mb-2"><strong>Patient:</strong> {{ $assignment->contract->patient->name ?? 'N/A' }}</p>
                    <p class="small mb-2"><strong>Service:</strong> {{ $assignment->contract->service->name ?? 'N/A' }}</p>
                    @if($assignment->is_emergency_replacement)
                        <p class="small mb-2">
                            <span class="badge bg-danger">Emergency Replacement</span>
                        </p>
                    @endif
                    <p class="small mb-2"><strong>Status:</strong> 
                        @if($assignment->is_active)
                            <span class="badge bg-success">Active</span>
                        @else
                            <span class="badge bg-secondary">Inactive</span>
                        @endif
                    </p>
                    <p class="small mb-2"><strong>Created:</strong> {{ $assignment->created_at->format('M d, Y') }}</p>
                    <p class="small mb-0"><strong>Last Updated:</strong> {{ $assignment->updated_at->diffForHumans() }}</p>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Note</h6>
                </div>
                <div class="card-body">
                    <p class="small text-muted mb-0">
                        Updating the assignment will automatically update the contract status. Deactivating this assignment may change the contract to "Not Assigned" status.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

