@extends('layouts.public')

@section('title', $blog->title)
@section('meta_description', $blog->excerpt)

@section('styles')
<style>
    .blog-header {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        color: white;
        padding: 60px 0 40px;
    }
    
    .blog-title {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 1rem;
    }
    
    .blog-meta {
        font-size: 1rem;
        opacity: 0.9;
    }
    
    .blog-meta i {
        margin-right: 0.5rem;
    }
    
    .blog-featured-image {
        width: 100%;
        max-height: 500px;
        object-fit: cover;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    
    .blog-content {
        font-size: 1.1rem;
        line-height: 1.8;
        color: #475569;
    }
    
    .blog-content h2 {
        color: var(--dark-color);
        font-weight: 600;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    
    .blog-content h3 {
        color: var(--dark-color);
        font-weight: 600;
        margin-top: 1.5rem;
        margin-bottom: 0.75rem;
    }
    
    .blog-content p {
        margin-bottom: 1.5rem;
    }
    
    .blog-content ul, .blog-content ol {
        margin-bottom: 1.5rem;
        padding-left: 2rem;
    }
    
    .blog-content li {
        margin-bottom: 0.5rem;
    }
    
    .share-buttons {
        background: #f8fafc;
        border-radius: 15px;
        padding: 1.5rem;
        margin: 2rem 0;
    }
    
    .share-buttons h5 {
        margin-bottom: 1rem;
        color: var(--dark-color);
    }
    
    .share-btn {
        display: inline-block;
        width: 40px;
        height: 40px;
        line-height: 40px;
        text-align: center;
        border-radius: 50%;
        color: white;
        margin-right: 0.5rem;
        transition: transform 0.3s;
    }
    
    .share-btn:hover {
        transform: translateY(-3px);
    }
    
    .share-btn.facebook { background: #1877f2; }
    .share-btn.twitter { background: #1da1f2; }
    .share-btn.linkedin { background: #0077b5; }
    .share-btn.whatsapp { background: #25d366; }
    
    .related-blog-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        transition: all 0.3s;
        height: 100%;
    }
    
    .related-blog-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    }
    
    .related-blog-image {
        width: 100%;
        height: 180px;
        object-fit: cover;
        background: linear-gradient(135deg, #e0e7ff 0%, #ddd6fe 100%);
    }
    
    .related-blog-content {
        padding: 1.25rem;
    }
    
    .related-blog-title {
        font-size: 1.1rem;
        font-weight: 600;
        color: var(--dark-color);
        margin-bottom: 0.5rem;
    }
    
    .related-blog-title a {
        color: var(--dark-color);
        text-decoration: none;
    }
    
    .related-blog-title a:hover {
        color: var(--primary-color);
    }
    
    @media (max-width: 768px) {
        .blog-title {
            font-size: 2rem;
        }
    }
</style>
@endsection

@section('content')
<!-- Blog Header -->
<section class="blog-header">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <h1 class="blog-title">{{ $blog->title }}</h1>
                <div class="blog-meta">
                    <span class="me-4">
                        <i class="far fa-calendar"></i> {{ $blog->published_at->format('F d, Y') }}
                    </span>
                    @if($blog->author)
                    <span class="me-4">
                        <i class="far fa-user"></i> {{ $blog->author->name }}
                    </span>
                    @endif
                    <span>
                        <i class="far fa-eye"></i> {{ $blog->views }} views
                    </span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Blog Content -->
<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <!-- Featured Image -->
                @if($blog->featured_image)
                <div class="mb-5">
                    <img src="{{ asset('storage/' . $blog->featured_image) }}" alt="{{ $blog->title }}" class="blog-featured-image">
                </div>
                @endif

                <!-- Excerpt -->
                @if($blog->excerpt)
                <div class="lead mb-4" style="font-size: 1.2rem; color: #64748b;">
                    {{ $blog->excerpt }}
                </div>
                @endif

                <!-- Content -->
                <div class="blog-content">
                    {!! nl2br(e($blog->content)) !!}
                </div>

                <!-- Share Buttons -->
                <div class="share-buttons">
                    <h5>Share this article</h5>
                    <a href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode(route('blogs.show', $blog->slug)) }}"
                       target="_blank" class="share-btn facebook">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="https://twitter.com/intent/tweet?url={{ urlencode(route('blogs.show', $blog->slug)) }}&text={{ urlencode($blog->title) }}"
                       target="_blank" class="share-btn twitter">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="https://www.linkedin.com/shareArticle?mini=true&url={{ urlencode(route('blogs.show', $blog->slug)) }}&title={{ urlencode($blog->title) }}"
                       target="_blank" class="share-btn linkedin">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a href="https://wa.me/?text={{ urlencode($blog->title . ' ' . route('blogs.show', $blog->slug)) }}"
                       target="_blank" class="share-btn whatsapp">
                        <i class="fab fa-whatsapp"></i>
                    </a>
                </div>

                <!-- Back to Blog -->
                <div class="text-center mt-4">
                    <a href="{{ route('blogs.index') }}" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Blog
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Related Blogs -->
@if($relatedBlogs->count() > 0)
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Related Articles</h2>
            <p class="section-subtitle">You might also be interested in</p>
        </div>
        <div class="row g-4">
            @foreach($relatedBlogs as $relatedBlog)
            <div class="col-lg-4 col-md-6">
                <div class="related-blog-card">
                    @if($relatedBlog->featured_image)
                    <img src="{{ asset('storage/' . $relatedBlog->featured_image) }}" alt="{{ $relatedBlog->title }}" class="related-blog-image">
                    @else
                    <div class="related-blog-image d-flex align-items-center justify-content-center">
                        <i class="fas fa-newspaper fa-4x text-white"></i>
                    </div>
                    @endif
                    <div class="related-blog-content">
                        <h5 class="related-blog-title">
                            <a href="{{ route('blogs.show', $relatedBlog->slug) }}">{{ $relatedBlog->title }}</a>
                        </h5>
                        <p class="text-muted small mb-2">
                            <i class="far fa-calendar me-1"></i> {{ $relatedBlog->published_at->format('M d, Y') }}
                        </p>
                        <p class="text-muted small">{{ Str::limit($relatedBlog->excerpt, 100) }}</p>
                        <a href="{{ route('blogs.show', $relatedBlog->slug) }}" class="btn btn-sm btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif
@endsection

