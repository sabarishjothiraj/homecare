<?php $__env->startSection('title', 'Contracts'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Contracts</h2>
            <p class="text-muted mb-0">Manage patient service contracts</p>
        </div>
        <a href="<?php echo e(route('admin.contracts.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Create New Contract
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Filters -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.contracts.index')); ?>" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Search</label>
                    <input type="text" name="search" class="form-control" placeholder="Search by contract number or patient name..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Patient</label>
                    <select name="patient_id" class="form-select">
                        <option value="">All Patients</option>
                        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($patient->id); ?>" <?php echo e(request('patient_id') == $patient->id ? 'selected' : ''); ?>>
                                <?php echo e($patient->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="">All Status</option>
                        <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="not_assigned" <?php echo e(request('status') === 'not_assigned' ? 'selected' : ''); ?>>Not Assigned</option>
                        <option value="closing_soon" <?php echo e(request('status') === 'closing_soon' ? 'selected' : ''); ?>>Closing Soon</option>
                        <option value="expired" <?php echo e(request('status') === 'expired' ? 'selected' : ''); ?>>Expired</option>
                        <option value="closed" <?php echo e(request('status') === 'closed' ? 'selected' : ''); ?>>Closed</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i>Filter
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Contracts Table -->
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <?php if($contracts->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Contract #</th>
                                <th>Patient</th>
                                <th>Service</th>
                                <th>Duration</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Assignment</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <strong class="text-primary"><?php echo e($contract->contract_number); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo e($contract->start_date->format('M d, Y')); ?></small>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary bg-opacity-10 rounded-circle p-2 me-2">
                                            <i class="fas fa-user text-primary"></i>
                                        </div>
                                        <div>
                                            <strong><?php echo e($contract->patient->name ?? 'N/A'); ?></strong>
                                            <br>
                                            <small class="text-muted"><?php echo e($contract->patient->community ?? ''); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <strong><?php echo e($contract->service->name ?? 'N/A'); ?></strong>
                                </td>
                                <td>
                                    <?php if($contract->duration_type === 'ongoing'): ?>
                                        <span class="badge bg-info">Ongoing</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">
                                            <?php echo e($contract->duration_value); ?> <?php echo e(ucfirst($contract->duration_type)); ?>

                                        </span>
                                        <?php if($contract->end_date): ?>
                                            <br><small class="text-muted">Until <?php echo e($contract->end_date->format('M d, Y')); ?></small>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong>₹<?php echo e(number_format($contract->amount, 0)); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo e(ucfirst(str_replace('_', ' ', $contract->payment_method))); ?></small>
                                </td>
                                <td>
                                    <?php if($contract->status === 'active'): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php elseif($contract->status === 'not_assigned'): ?>
                                        <span class="badge bg-warning">Not Assigned</span>
                                    <?php elseif($contract->status === 'closing_soon'): ?>
                                        <span class="badge bg-warning">Closing Soon</span>
                                    <?php elseif($contract->status === 'expired'): ?>
                                        <span class="badge bg-danger">Expired</span>
                                    <?php elseif($contract->status === 'closed'): ?>
                                        <span class="badge bg-secondary">Closed</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e(ucfirst($contract->status)); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($contract->activeAssignment): ?>
                                        <span class="badge bg-success">
                                            <i class="fas fa-user-nurse me-1"></i>
                                            <?php echo e($contract->activeAssignment->employee->getField('name', 'Assigned')); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Not Assigned</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('admin.contracts.show', $contract)); ?>" class="btn btn-outline-primary" title="View">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if($contract->status !== 'closed'): ?>
                                            <a href="<?php echo e(route('admin.contracts.edit', $contract)); ?>" class="btn btn-outline-warning" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="card-footer bg-white">
                    <?php echo e($contracts->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-file-contract fa-4x text-muted mb-3 opacity-25"></i>
                    <h5 class="text-muted">No contracts found</h5>
                    <p class="text-muted">Start by creating your first contract</p>
                    <a href="<?php echo e(route('admin.contracts.create')); ?>" class="btn btn-primary mt-3">
                        <i class="fas fa-plus me-2"></i>Create New Contract
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Sabarish\Mohawk\workspace\mani\homecare\resources\views/admin/contracts/index.blade.php ENDPATH**/ ?>