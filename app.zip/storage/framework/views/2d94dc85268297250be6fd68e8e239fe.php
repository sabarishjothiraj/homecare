<?php $__env->startSection('title', 'Contract Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1"><?php echo e($contract->contract_number); ?></h2>
            <p class="text-muted mb-0">Contract Details</p>
        </div>
        <div>
            <?php if($contract->pdf_path): ?>
                <a href="<?php echo e(route('admin.contracts.download', $contract)); ?>" class="btn btn-success">
                    <i class="fas fa-download me-2"></i>Download PDF
                </a>
                <a href="<?php echo e(route('admin.contracts.print-pdf', $contract)); ?>" class="btn btn-outline-primary" target="_blank">
                    <i class="fas fa-print me-2"></i>Print PDF
                </a>
            <?php endif; ?>
            <?php if($contract->status !== 'closed'): ?>
                <a href="<?php echo e(route('admin.contracts.edit', $contract)); ?>" class="btn btn-warning">
                    <i class="fas fa-edit me-2"></i>Edit
                </a>
            <?php endif; ?>
            <a href="<?php echo e(route('admin.contracts.index')); ?>" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to List
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-3">
        <!-- Contract Information -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-file-contract me-2"></i>Contract Information</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="text-muted small">Contract Number</label>
                            <p class="mb-0"><strong><?php echo e($contract->contract_number); ?></strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Status</label>
                            <p class="mb-0">
                                <?php if($contract->status === 'active'): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php elseif($contract->status === 'not_assigned'): ?>
                                    <span class="badge bg-warning">Not Assigned</span>
                                <?php elseif($contract->status === 'closing_soon'): ?>
                                    <span class="badge bg-warning">Closing Soon</span>
                                <?php elseif($contract->status === 'expired'): ?>
                                    <span class="badge bg-danger">Expired</span>
                                <?php elseif($contract->status === 'closed'): ?>
                                    <span class="badge bg-secondary">Closed</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e(ucfirst($contract->status)); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Patient</label>
                            <p class="mb-0">
                                <strong><?php echo e($contract->patient->name ?? 'N/A'); ?></strong><br>
                                <small class="text-muted"><?php echo e($contract->patient->community ?? ''); ?> - <?php echo e($contract->patient->location ?? ''); ?></small>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Services</label>
                            <p class="mb-0">
                                <?php if($contract->items->count() > 0): ?>
                                    <strong><?php echo e($contract->items->pluck('service.name')->filter()->unique()->join(', ')); ?></strong>
                                <?php else: ?>
                                    <strong><?php echo e($contract->service->name ?? 'N/A'); ?></strong>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Start Date</label>
                            <p class="mb-0"><strong><?php echo e($contract->start_date->format('M d, Y')); ?></strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">End Date</label>
                            <p class="mb-0">
                                <?php if($contract->end_date): ?>
                                    <strong><?php echo e($contract->end_date->format('M d, Y')); ?></strong>
                                <?php else: ?>
                                    <span class="badge bg-info">Ongoing</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Duration</label>
                            <p class="mb-0">
                                <?php if($contract->duration_type === 'custom'): ?>
                                    <span class="badge bg-info">Custom</span>
                                <?php else: ?>
                                    <strong><?php echo e($contract->duration_value); ?> <?php echo e(ucfirst($contract->duration_type)); ?></strong>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Contract Amount</label>
                            <p class="mb-0"><strong class="text-success">₹<?php echo e(number_format($contract->amount, 0)); ?></strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Payment Method</label>
                            <p class="mb-0"><strong><?php echo e(ucfirst(str_replace('_', ' ', $contract->payment_method))); ?></strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Created</label>
                            <p class="mb-0"><?php echo e($contract->created_at->format('M d, Y h:i A')); ?></p>
                        </div>
                        <?php if($contract->terms): ?>
                            <div class="col-12">
                                <label class="text-muted small">Terms and Conditions</label>
                                <p class="mb-0"><?php echo e($contract->terms); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php if($contract->closure_reason): ?>
                            <div class="col-12">
                                <label class="text-muted small">Closure Reason</label>
                                <p class="mb-0 text-danger"><?php echo e($contract->closure_reason); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Employee Assignments -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-tasks me-2"></i>Employee Assignments</h5>
                </div>
                <div class="card-body p-0">
                    <?php if($contract->assignments->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Employee</th>
                                        <th>Service</th>
                                        <th>Amount</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                        <th>Type</th>
                                        <th>Limit</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $contract->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $line = $assignment->contractItem;
                                        $canReplace = $line ? $line->assignment_count < $line->max_assignments : true;
                                        $remaining = $line ? max(0, $line->max_assignments - $line->assignment_count) : null;
                                    ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo e($assignment->employee->getField('name', 'N/A')); ?></strong>
                                            <br>
                                            <small class="text-muted"><?php echo e($assignment->employee->getField('phone', '')); ?></small>
                                        </td>
                                        <td><?php echo e($assignment->service->name ?? $assignment->contractItem->service->name ?? ($contract->service->name ?? 'N/A')); ?></td>
                                        <td>₹<?php echo e(number_format($assignment->line_amount ?? $assignment->contractItem->amount ?? $contract->amount, 0)); ?></td>
                                        <td><?php echo e($assignment->start_date->format('M d, Y')); ?></td>
                                        <td><?php echo e($assignment->end_date ? $assignment->end_date->format('M d, Y') : 'Ongoing'); ?></td>
                                        <td>
                                            <?php if($assignment->is_active): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($assignment->is_emergency_replacement): ?>
                                                <span class="badge bg-info">Temporary</span>
                                                <?php if($assignment->replacedAssignment): ?>
                                                    <br>
                                                    <small class="text-muted">For: <?php echo e($assignment->replacedAssignment->employee->getField('name', 'N/A')); ?></small>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="badge bg-light text-dark">Primary</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($line): ?>
                                                <span class="badge <?php echo e($canReplace ? 'bg-info' : 'bg-secondary'); ?>" title="Initial assignment is included in this count.">
                                                    <?php echo e($line->assignment_count); ?>/<?php echo e($line->max_assignments); ?>

                                                </span>
                                                <br>
                                                <small class="text-muted">Remaining: <?php echo e($remaining); ?></small>
                                            <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($contract->status !== 'closed' && $contract->status !== 'expired'): ?>
                                                <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="collapse" data-bs-target="#assignment-actions-<?php echo e($assignment->id); ?>">
                                                    <i class="fas fa-cog"></i>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php if($contract->status !== 'closed' && $contract->status !== 'expired'): ?>
                                    <tr class="bg-light collapse" id="assignment-actions-<?php echo e($assignment->id); ?>">
                                        <td colspan="9">
                                            <div class="row g-3 p-2">
                                                <div class="col-lg-4">
                                                    <h6 class="mb-2">Add Note</h6>
                                                    <form action="<?php echo e(route('admin.contracts.assignments.notes.store', [$contract, $assignment])); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <textarea name="note" class="form-control form-control-sm mb-2" rows="2" placeholder="Add remark for this employee" required></textarea>
                                                        <button type="submit" class="btn btn-sm btn-outline-primary">Save Note</button>
                                                    </form>
                                                </div>
                                                <div class="col-lg-4">
                                                    <h6 class="mb-2">Replace Employee</h6>
                                                    <form action="<?php echo e(route('admin.contracts.assignments.replace', [$contract, $assignment])); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="mb-2">
                                                            <select name="employee_id" class="form-select form-select-sm" required <?php echo e(!$canReplace ? 'disabled' : ''); ?>>
                                                                <option value="">Select replacement</option>
                                                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php
                                                                        $lineServiceId = $line ? (int) $line->service_id : null;
                                                                        $eligible = !$lineServiceId || $employee->services->pluck('id')->contains($lineServiceId);
                                                                    ?>
                                                                    <?php if($eligible): ?>
                                                                        <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->getField('name', 'Employee #' . $employee->id)); ?></option>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="row g-2 mb-2">
                                                            <div class="col-6">
                                                                <input type="date" name="replacement_start_date" class="form-control form-control-sm" value="<?php echo e(now()->format('Y-m-d')); ?>" required <?php echo e(!$canReplace ? 'disabled' : ''); ?>>
                                                            </div>
                                                            <div class="col-6">
                                                                <input type="date" name="replacement_end_date" class="form-control form-control-sm" placeholder="End date (optional)" <?php echo e(!$canReplace ? 'disabled' : ''); ?>>
                                                            </div>
                                                        </div>
                                                        <div class="form-check mb-2">
                                                            <input type="checkbox" class="form-check-input" id="is_temporary_<?php echo e($assignment->id); ?>" name="is_temporary" value="1" <?php echo e(!$canReplace ? 'disabled' : ''); ?>>
                                                            <label class="form-check-label small" for="is_temporary_<?php echo e($assignment->id); ?>">Temporary replacement</label>
                                                        </div>
                                                        <textarea name="notes" class="form-control form-control-sm mb-2" rows="2" placeholder="Replacement note (optional)" <?php echo e(!$canReplace ? 'disabled' : ''); ?>></textarea>
                                                        <?php if($canReplace): ?>
                                                            <button type="submit" class="btn btn-sm btn-outline-warning">Replace</button>
                                                        <?php else: ?>
                                                            <button type="button" class="btn btn-sm btn-outline-secondary" disabled title="Maximum employee changes reached for this service line.">Replace Limit Reached</button>
                                                        <?php endif; ?>
                                                    </form>
                                                </div>
                                                <div class="col-lg-4">
                                                    <h6 class="mb-2">Remove Assignment</h6>
                                                    <form action="<?php echo e(route('admin.contracts.assignments.remove', [$contract, $assignment])); ?>" method="POST" onsubmit="return confirm('Remove this employee from contract?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-outline-danger">Remove Employee</button>
                                                    </form>
                                                </div>

                                                <?php if($assignment->assignmentNotes->count() > 0): ?>
                                                    <div class="col-12 mt-2">
                                                        <h6 class="mb-2">Notes</h6>
                                                        <ul class="mb-0 small">
                                                            <?php $__currentLoopData = $assignment->assignmentNotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li>
                                                                    <?php echo e($note->note); ?>

                                                                    <span class="text-muted">- <?php echo e($note->creator->name ?? 'System'); ?>, <?php echo e($note->created_at->format('M d, Y h:i A')); ?></span>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-tasks fa-3x text-muted mb-3 opacity-25"></i>
                            <p class="text-muted">No employees assigned yet</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Payments -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-money-bill-wave me-2"></i>Payments</h5>
                </div>
                <div class="card-body p-0">
                    <?php if($contract->payments->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Method</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $contract->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($payment->created_at->format('M d, Y')); ?></td>
                                        <td><strong>₹<?php echo e(number_format($payment->amount, 0)); ?></strong></td>
                                        <td><?php echo e(ucfirst(str_replace('_', ' ', $payment->payment_method))); ?></td>
                                        <td>
                                            <span class="badge bg-success">Paid</span>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-money-bill-wave fa-3x text-muted mb-3 opacity-25"></i>
                            <p class="text-muted">No payments recorded</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-md-4">
            <!-- Actions Card -->
            <?php if($contract->status !== 'closed'): ?>
                <div class="card border-0 shadow-sm mb-3">
                    <div class="card-header bg-white">
                        <h6 class="mb-0"><i class="fas fa-cog me-2"></i>Actions</h6>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.contracts.regenerate-pdf', $contract)); ?>" method="POST" class="mb-2">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-primary w-100">
                                <i class="fas fa-sync me-2"></i>Regenerate PDF
                            </button>
                        </form>
                        
                        <?php if($contract->status !== 'expired'): ?>
                            <button type="button" class="btn btn-outline-danger w-100" data-bs-toggle="modal" data-bs-target="#closeContractModal">
                                <i class="fas fa-times-circle me-2"></i>Close Contract
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Patient Info Card -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-user me-2"></i>Patient Information</h6>
                </div>
                <div class="card-body">
                    <p class="small mb-2"><strong>Name:</strong> <?php echo e($contract->patient->name ?? 'N/A'); ?></p>
                    <p class="small mb-2"><strong>Phone:</strong> <?php echo e($contract->patient->phone ?? 'N/A'); ?></p>
                    <p class="small mb-2"><strong>Email:</strong> <?php echo e($contract->patient->email ?? 'N/A'); ?></p>
                    <p class="small mb-0"><strong>Location:</strong> <?php echo e($contract->patient->location ?? 'N/A'); ?></p>
                    <a href="<?php echo e(route('admin.patients.show', $contract->patient)); ?>" class="btn btn-sm btn-outline-primary w-100 mt-3">
                        View Patient Details
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Close Contract Modal -->
<?php if($contract->status !== 'closed' && $contract->status !== 'expired'): ?>
<div class="modal fade" id="closeContractModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('admin.contracts.close', $contract)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Close Contract</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        This action will close the contract and end all active assignments.
                    </div>
                    <div class="mb-3">
                        <label for="closure_reason" class="form-label">Closure Reason <span class="text-danger">*</span></label>
                        <textarea class="form-control" id="closure_reason" name="closure_reason" rows="3" required placeholder="Enter reason for closing this contract"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Close Contract</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Downloads\Extract\Mohawk\Mohawk\workspace\mani\homecare\resources\views/admin/contracts/show.blade.php ENDPATH**/ ?>