<?php $__env->startSection('title', 'Blog'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .page-header {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        color: white;
        padding: 80px 0 60px;
        text-align: center;
    }
    
    .page-header h1 {
        font-size: 3rem;
        font-weight: 700;
        margin-bottom: 1rem;
    }
    
    .blog-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        transition: all 0.3s;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    
    .blog-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    }
    
    .blog-image {
        width: 100%;
        height: 250px;
        object-fit: cover;
        background: linear-gradient(135deg, #e0e7ff 0%, #ddd6fe 100%);
    }
    
    .blog-content {
        padding: 1.5rem;
        flex-grow: 1;
        display: flex;
        flex-direction: column;
    }
    
    .blog-title {
        font-size: 1.3rem;
        font-weight: 600;
        color: var(--dark-color);
        margin-bottom: 0.75rem;
    }
    
    .blog-title a {
        color: var(--dark-color);
        text-decoration: none;
        transition: color 0.3s;
    }
    
    .blog-title a:hover {
        color: var(--primary-color);
    }
    
    .blog-excerpt {
        color: #64748b;
        font-size: 0.95rem;
        margin-bottom: 1rem;
        flex-grow: 1;
    }
    
    .blog-meta {
        font-size: 0.85rem;
        color: #94a3b8;
        padding-top: 1rem;
        border-top: 1px solid #e2e8f0;
    }
    
    .blog-meta i {
        margin-right: 0.25rem;
    }
    
    .pagination {
        margin-top: 2rem;
    }
    
    .pagination .page-link {
        color: var(--primary-color);
        border-radius: 8px;
        margin: 0 0.25rem;
        border: 2px solid #e2e8f0;
    }
    
    .pagination .page-link:hover {
        background: var(--primary-color);
        color: white;
        border-color: var(--primary-color);
    }
    
    .pagination .page-item.active .page-link {
        background: var(--primary-color);
        border-color: var(--primary-color);
    }
    
    .no-blogs {
        text-align: center;
        padding: 4rem 0;
    }
    
    .no-blogs i {
        font-size: 5rem;
        color: #cbd5e1;
        margin-bottom: 1.5rem;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <h1>Our Blog</h1>
        <p class="lead">Healthcare tips, news, and insights from our experts</p>
    </div>
</section>

<!-- Blog Listing -->
<section class="py-5">
    <div class="container">
        <?php if($blogs->count() > 0): ?>
        <div class="row g-4">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="blog-card">
                    <?php if($blog->featured_image): ?>
                    <img src="<?php echo e(asset('storage/' . $blog->featured_image)); ?>" alt="<?php echo e($blog->title); ?>" class="blog-image">
                    <?php else: ?>
                    <div class="blog-image d-flex align-items-center justify-content-center">
                        <i class="fas fa-newspaper fa-5x text-white"></i>
                    </div>
                    <?php endif; ?>
                    <div class="blog-content">
                        <h3 class="blog-title">
                            <a href="<?php echo e(route('blogs.show', $blog->slug)); ?>"><?php echo e($blog->title); ?></a>
                        </h3>
                        <p class="blog-excerpt"><?php echo e(Str::limit($blog->excerpt, 150)); ?></p>
                        <div class="blog-meta">
                            <div class="d-flex justify-content-between align-items-center">
                                <span>
                                    <i class="far fa-calendar"></i> <?php echo e($blog->published_at->format('M d, Y')); ?>

                                </span>
                                <span>
                                    <i class="far fa-eye"></i> <?php echo e($blog->views); ?> views
                                </span>
                            </div>
                            <?php if($blog->author): ?>
                            <div class="mt-2">
                                <i class="far fa-user"></i> <?php echo e($blog->author->name); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <!-- Pagination -->
        <div class="d-flex justify-content-center mt-5">
            <?php echo e($blogs->links()); ?>

        </div>
        <?php else: ?>
        <div class="no-blogs">
            <i class="fas fa-newspaper"></i>
            <h3>No Blog Posts Yet</h3>
            <p class="text-muted">Check back soon for healthcare tips and insights from our experts.</p>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Sabarish\Mohawk\workspace\mani\homenursing\resources\views/web/blogs/index.blade.php ENDPATH**/ ?>