

<?php $__env->startSection('title', 'User Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">User Details</h2>
            <p class="text-muted mb-0">Account details for <?php echo e($user->name); ?></p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-warning">
                <i class="fas fa-edit me-2"></i>Edit
            </a>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to Users
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-user-shield me-2"></i>User Information</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <small class="text-muted d-block">Name</small>
                            <strong><?php echo e($user->name); ?></strong>
                        </div>
                        <div class="col-md-6">
                            <small class="text-muted d-block">Username</small>
                            <strong><?php echo e($user->username ?: 'N/A'); ?></strong>
                        </div>
                        <div class="col-md-6">
                            <small class="text-muted d-block">Email</small>
                            <strong><?php echo e($user->email); ?></strong>
                        </div>
                        <div class="col-md-3">
                            <small class="text-muted d-block">Role</small>
                            <span class="badge <?php echo e($user->role === 'super_admin' ? 'bg-danger' : 'bg-info'); ?>">
                                <?php echo e(str_replace('_', ' ', ucfirst($user->role))); ?>

                            </span>
                        </div>
                        <div class="col-md-3">
                            <small class="text-muted d-block">Status</small>
                            <?php if($user->is_active): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Inactive</span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <small class="text-muted d-block">Created At</small>
                            <strong><?php echo e($user->created_at->format('M d, Y h:i A')); ?></strong>
                        </div>
                        <div class="col-md-6">
                            <small class="text-muted d-block">Last Updated</small>
                            <strong><?php echo e($user->updated_at->format('M d, Y h:i A')); ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h6>
                </div>
                <div class="card-body d-grid gap-2">
                    <?php if($user->is_active): ?>
                        <form action="<?php echo e(route('admin.users.deactivate', $user)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-user-slash me-2"></i>Set Inactive
                            </button>
                        </form>
                    <?php else: ?>
                        <form action="<?php echo e(route('admin.users.activate', $user)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="btn btn-outline-success w-100">
                                <i class="fas fa-user-check me-2"></i>Set Active
                            </button>
                        </form>
                    <?php endif; ?>

                    <?php if(auth()->id() !== $user->id): ?>
                        <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this user?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-outline-danger w-100">
                                <i class="fas fa-trash me-2"></i>Delete User
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Downloads\Extract\Mohawk\Mohawk\workspace\mani\homecare\resources\views/admin/users/show.blade.php ENDPATH**/ ?>