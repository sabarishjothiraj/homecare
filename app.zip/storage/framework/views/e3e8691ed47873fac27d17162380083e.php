<?php $__env->startSection('title', 'Edit Contract'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Edit Contract</h2>
            <p class="text-muted mb-0">Update contract information - <?php echo e($contract->contract_number); ?></p>
        </div>
        <a href="<?php echo e(route('admin.contracts.show', $contract)); ?>" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to Contract
        </a>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-file-contract me-2"></i>Contract Information</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.contracts.update', $contract)); ?>" method="POST" data-ajax="true">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row g-3">
                            <!-- Patient Selection -->
                            <div class="col-md-6">
                                <label for="patient_id" class="form-label">
                                    Patient <span class="text-danger">*</span>
                                </label>
                                <select class="form-select <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                        id="patient_id" 
                                        name="patient_id" 
                                        required>
                                    <option value="">Select Patient</option>
                                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($patient->id); ?>" <?php echo e(old('patient_id', $contract->patient_id) == $patient->id ? 'selected' : ''); ?>>
                                            <?php echo e($patient->name); ?> - <?php echo e($patient->community); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Service Selection -->
                            <div class="col-md-6">
                                <label for="service_id" class="form-label">
                                    Service <span class="text-danger">*</span>
                                </label>
                                <select class="form-select <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                        id="service_id" 
                                        name="service_id" 
                                        required>
                                    <option value="">Select Service</option>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($service->id); ?>" <?php echo e(old('service_id', $contract->service_id) == $service->id ? 'selected' : ''); ?>>
                                            <?php echo e($service->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Start Date -->
                            <div class="col-md-6">
                                <label for="start_date" class="form-label">
                                    Start Date <span class="text-danger">*</span>
                                </label>
                                <input type="date" 
                                       class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="start_date" 
                                       name="start_date" 
                                       value="<?php echo e(old('start_date', $contract->start_date->format('Y-m-d'))); ?>"
                                       required>
                                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Duration Type -->
                            <div class="col-md-6">
                                <label for="duration_type" class="form-label">
                                    Duration Type <span class="text-danger">*</span>
                                </label>
                                <select class="form-select <?php $__errorArgs = ['duration_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="duration_type"
                                        name="duration_type"
                                        required>
                                    <option value="">Select Duration Type</option>
                                    <option value="daily" <?php echo e(old('duration_type', $contract->duration_type) === 'daily' ? 'selected' : ''); ?>>Daily</option>
                                    <option value="weekly" <?php echo e(old('duration_type', $contract->duration_type) === 'weekly' ? 'selected' : ''); ?>>Weekly</option>
                                    <option value="monthly" <?php echo e(old('duration_type', $contract->duration_type) === 'monthly' ? 'selected' : ''); ?>>Monthly</option>
                                    <option value="yearly" <?php echo e(old('duration_type', $contract->duration_type) === 'yearly' ? 'selected' : ''); ?>>Yearly</option>
                                    <option value="custom" <?php echo e(old('duration_type', $contract->duration_type) === 'custom' ? 'selected' : ''); ?>>Custom</option>
                                </select>
                                <?php $__errorArgs = ['duration_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Duration Value -->
                            <div class="col-md-6" id="duration_value_container">
                                <label for="duration_value" class="form-label">
                                    Duration Value <span class="text-danger" id="duration_required">*</span>
                                </label>
                                <input type="number" 
                                       class="form-control <?php $__errorArgs = ['duration_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="duration_value" 
                                       name="duration_value" 
                                       value="<?php echo e(old('duration_value', $contract->duration_value)); ?>"
                                       min="1"
                                       placeholder="Enter number of days/months">
                                <?php $__errorArgs = ['duration_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Amount -->
                            <div class="col-md-6">
                                <label for="amount" class="form-label">
                                    Contract Amount (₹) <span class="text-danger">*</span>
                                </label>
                                <input type="number" 
                                       class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="amount" 
                                       name="amount" 
                                       value="<?php echo e(old('amount', $contract->amount)); ?>"
                                       min="0"
                                       step="0.01"
                                       required
                                       placeholder="Enter amount">
                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Payment Method -->
                            <div class="col-md-6">
                                <label for="payment_method" class="form-label">
                                    Payment Method <span class="text-danger">*</span>
                                </label>
                                <select class="form-select <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                        id="payment_method" 
                                        name="payment_method" 
                                        required>
                                    <option value="">Select Payment Method</option>
                                    <option value="online" <?php echo e(old('payment_method', $contract->payment_method) === 'online' ? 'selected' : ''); ?>>Online</option>
                                    <option value="cash" <?php echo e(old('payment_method', $contract->payment_method) === 'cash' ? 'selected' : ''); ?>>Cash</option>
                                    <option value="cheque" <?php echo e(old('payment_method', $contract->payment_method) === 'cheque' ? 'selected' : ''); ?>>Cheque</option>
                                    <option value="bank_transfer" <?php echo e(old('payment_method', $contract->payment_method) === 'bank_transfer' ? 'selected' : ''); ?>>Bank Transfer</option>
                                </select>
                                <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Terms and Conditions -->
                            <div class="col-12">
                                <label for="terms" class="form-label">Terms and Conditions</label>
                                <textarea class="form-control <?php $__errorArgs = ['terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                          id="terms" 
                                          name="terms" 
                                          rows="4"
                                          placeholder="Enter any special terms or conditions for this contract"><?php echo e(old('terms', $contract->terms)); ?></textarea>
                                <?php $__errorArgs = ['terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Update Contract
                            </button>
                            <a href="<?php echo e(route('admin.contracts.show', $contract)); ?>" class="btn btn-outline-secondary">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Contract Details</h6>
                </div>
                <div class="card-body">
                    <p class="small mb-2"><strong>Contract Number:</strong> <?php echo e($contract->contract_number); ?></p>
                    <p class="small mb-2"><strong>Status:</strong> 
                        <?php if($contract->status === 'active'): ?>
                            <span class="badge bg-success">Active</span>
                        <?php elseif($contract->status === 'not_assigned'): ?>
                            <span class="badge bg-warning">Not Assigned</span>
                        <?php elseif($contract->status === 'closing_soon'): ?>
                            <span class="badge bg-warning">Closing Soon</span>
                        <?php elseif($contract->status === 'expired'): ?>
                            <span class="badge bg-danger">Expired</span>
                        <?php else: ?>
                            <span class="badge bg-secondary"><?php echo e(ucfirst($contract->status)); ?></span>
                        <?php endif; ?>
                    </p>
                    <p class="small mb-2"><strong>Created:</strong> <?php echo e($contract->created_at->format('M d, Y')); ?></p>
                    <p class="small mb-0"><strong>Last Updated:</strong> <?php echo e($contract->updated_at->diffForHumans()); ?></p>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Note</h6>
                </div>
                <div class="card-body">
                    <p class="small text-muted mb-0">
                        Updating the contract will recalculate the end date and update the contract status automatically.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const durationTypeSelect = document.getElementById('duration_type');
    const durationValueContainer = document.getElementById('duration_value_container');
    const durationValueInput = document.getElementById('duration_value');

    durationTypeSelect.addEventListener('change', function() {
        if (this.value === 'custom') {
            durationValueInput.value = '';
            durationValueInput.removeAttribute('required');
            durationValueContainer.style.display = 'none';
        } else {
            durationValueInput.setAttribute('required', 'required');
            durationValueContainer.style.display = 'block';
        }
    });

    // Trigger on page load
    if (durationTypeSelect.value === 'custom') {
        durationValueContainer.style.display = 'none';
        durationValueInput.removeAttribute('required');
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Downloads\Extract\Mohawk\Mohawk\workspace\mani\homecare\resources\views/admin/contracts/edit.blade.php ENDPATH**/ ?>