<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    /* Banner Carousel */
    .banner-carousel {
        position: relative;
        margin-top: -20px;
    }

    .banner-carousel .carousel-item {
        height: 500px;
        position: relative;
    }

    .banner-carousel .carousel-item img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .banner-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(to right, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 100%);
        display: flex;
        align-items: center;
    }

    .banner-content {
        color: white;
        z-index: 2;
    }

    .banner-title {
        font-size: 3.5rem;
        font-weight: 700;
        margin-bottom: 1rem;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
    }

    .banner-subtitle {
        font-size: 1.5rem;
        margin-bottom: 2rem;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
    }

    .banner-carousel .carousel-control-prev,
    .banner-carousel .carousel-control-next {
        width: 5%;
    }

    .banner-carousel .carousel-indicators {
        margin-bottom: 2rem;
    }

    @media (max-width: 768px) {
        .banner-carousel .carousel-item {
            height: 400px;
        }
        .banner-title {
            font-size: 2rem;
        }
        .banner-subtitle {
            font-size: 1.1rem;
        }
    }

    /* Hero Section */
    .hero-section {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        color: white;
        padding: 100px 0;
        position: relative;
        overflow: hidden;
    }
    
    .hero-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(255,255,255,0.1)" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,138.7C960,139,1056,117,1152,101.3C1248,85,1344,75,1392,69.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') no-repeat bottom;
        background-size: cover;
    }
    
    .hero-content {
        position: relative;
        z-index: 1;
    }
    
    .hero-title {
        font-size: 3.5rem;
        font-weight: 700;
        margin-bottom: 1.5rem;
    }
    
    .hero-subtitle {
        font-size: 1.3rem;
        margin-bottom: 2rem;
        opacity: 0.95;
    }
    
    /* Service Card */
    .service-card {
        background: white;
        border-radius: 15px;
        padding: 2rem;
        text-align: center;
        transition: all 0.3s;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        height: 100%;
    }
    
    .service-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    }
    
    .service-icon {
        font-size: 3rem;
        color: var(--primary-color);
        margin-bottom: 1.5rem;
    }
    
    .service-card h4 {
        color: var(--dark-color);
        font-weight: 600;
        margin-bottom: 1rem;
    }
    
    /* Blog Card */
    .blog-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        transition: all 0.3s;
        height: 100%;
    }
    
    .blog-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    }
    
    .blog-image {
        width: 100%;
        height: 200px;
        object-fit: cover;
        background: linear-gradient(135deg, #e0e7ff 0%, #ddd6fe 100%);
    }
    
    .blog-content {
        padding: 1.5rem;
    }
    
    .blog-title {
        font-size: 1.2rem;
        font-weight: 600;
        color: var(--dark-color);
        margin-bottom: 0.5rem;
    }
    
    .blog-excerpt {
        color: #64748b;
        font-size: 0.9rem;
        margin-bottom: 1rem;
    }
    
    .blog-meta {
        font-size: 0.85rem;
        color: #94a3b8;
    }
    
    /* CTA Section */
    .cta-section {
        background: linear-gradient(135deg, var(--accent-color) 0%, var(--primary-color) 100%);
        color: white;
        padding: 80px 0;
        text-align: center;
    }
    
    .cta-section h2 {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 1rem;
    }
    
    .btn-light {
        background: white;
        color: var(--primary-color);
        padding: 0.75rem 2rem;
        font-weight: 600;
        border: none;
        transition: all 0.3s;
    }
    
    .btn-light:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.2);
    }
    
    @media (max-width: 768px) {
        .hero-title {
            font-size: 2.5rem;
        }
        .hero-subtitle {
            font-size: 1.1rem;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Banner Carousel -->
<?php if($banners->count() > 0): ?>
<div id="bannerCarousel" class="carousel slide banner-carousel" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button type="button" data-bs-target="#bannerCarousel" data-bs-slide-to="<?php echo e($index); ?>"
                class="<?php echo e($index === 0 ? 'active' : ''); ?>"
                aria-current="<?php echo e($index === 0 ? 'true' : 'false'); ?>"
                aria-label="Slide <?php echo e($index + 1); ?>"></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="carousel-inner">
        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
            <img src="<?php echo e($banner->image_url); ?>" alt="<?php echo e($banner->title); ?>">
            <div class="banner-overlay">
                <div class="container">
                    <div class="banner-content">
                        <h1 class="banner-title"><?php echo e($banner->title); ?></h1>
                        <?php if($banner->subtitle): ?>
                        <p class="banner-subtitle"><?php echo e($banner->subtitle); ?></p>
                        <?php endif; ?>
                        <?php if($banner->link && $banner->button_text): ?>
                        <a href="<?php echo e($banner->link); ?>" class="btn btn-primary btn-lg">
                            <?php echo e($banner->button_text); ?>

                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#bannerCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#bannerCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
<?php endif; ?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 hero-content">
                <h1 class="hero-title"><?php echo e($homeIntroTitle); ?></h1>
                <p class="hero-subtitle"><?php echo e($homeIntroContent ?: 'Professional nursing care in the comfort of your home. Our experienced healthcare professionals provide compassionate, personalized care tailored to your needs.'); ?></p>
                <div>
                    <a href="<?php echo e(route('services')); ?>" class="btn btn-light btn-lg me-3">Our Services</a>
                    <a href="<?php echo e(route('contact')); ?>" class="btn btn-outline-light btn-lg">Contact Us</a>
                </div>
            </div>
            <div class="col-lg-6 text-center mt-5 mt-lg-0">
                <i class="fas fa-user-nurse" style="font-size: 15rem; opacity: 0.2;"></i>
            </div>
        </div>
    </div>
</section>

<!-- Services Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Our Services</h2>
            <p class="section-subtitle">Comprehensive healthcare solutions delivered at your doorstep</p>
        </div>
        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="<?php echo e($service->icon ?: 'fas fa-heartbeat'); ?>"></i>
                    </div>
                    <h4><?php echo e($service->name); ?></h4>
                    <p class="text-muted"><?php echo e(Str::limit($service->description, 120)); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center">
                <p class="text-muted">No services available at the moment.</p>
            </div>
            <?php endif; ?>
        </div>
        <?php if($services->count() > 0): ?>
        <div class="text-center mt-5">
            <a href="<?php echo e(route('services')); ?>" class="btn btn-primary btn-lg">View All Services</a>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Why Choose Us Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Why Choose Us</h2>
            <p class="section-subtitle">Excellence in home healthcare services</p>
        </div>
        <div class="row g-4">
            <div class="col-lg-3 col-md-6 text-center">
                <div class="mb-3">
                    <i class="fas fa-user-md fa-3x text-primary"></i>
                </div>
                <h5>Qualified Professionals</h5>
                <p class="text-muted">Experienced and certified healthcare professionals</p>
            </div>
            <div class="col-lg-3 col-md-6 text-center">
                <div class="mb-3">
                    <i class="fas fa-clock fa-3x text-primary"></i>
                </div>
                <h5>24/7 Availability</h5>
                <p class="text-muted">Round-the-clock care whenever you need it</p>
            </div>
            <div class="col-lg-3 col-md-6 text-center">
                <div class="mb-3">
                    <i class="fas fa-home fa-3x text-primary"></i>
                </div>
                <h5>Home Comfort</h5>
                <p class="text-muted">Quality care in the comfort of your home</p>
            </div>
            <div class="col-lg-3 col-md-6 text-center">
                <div class="mb-3">
                    <i class="fas fa-dollar-sign fa-3x text-primary"></i>
                </div>
                <h5>Affordable Pricing</h5>
                <p class="text-muted">Competitive rates without compromising quality</p>
            </div>
        </div>
    </div>
</section>

<!-- Recent Blogs Section -->
<?php if($recentBlogs->count() > 0): ?>
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Latest from Our Blog</h2>
            <p class="section-subtitle">Stay informed with healthcare tips and news</p>
        </div>
        <div class="row g-4">
            <?php $__currentLoopData = $recentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="blog-card">
                    <?php if($blog->featured_image): ?>
                    <img src="<?php echo e(asset('storage/' . $blog->featured_image)); ?>" alt="<?php echo e($blog->title); ?>" class="blog-image">
                    <?php else: ?>
                    <div class="blog-image d-flex align-items-center justify-content-center">
                        <i class="fas fa-newspaper fa-4x text-white"></i>
                    </div>
                    <?php endif; ?>
                    <div class="blog-content">
                        <h5 class="blog-title"><?php echo e($blog->title); ?></h5>
                        <p class="blog-excerpt"><?php echo e(Str::limit($blog->excerpt, 100)); ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="blog-meta">
                                <i class="far fa-calendar"></i> <?php echo e($blog->published_at->format('M d, Y')); ?>

                            </span>
                            <a href="<?php echo e(route('blogs.show', $blog->slug)); ?>" class="btn btn-sm btn-primary">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="text-center mt-5">
            <a href="<?php echo e(route('blogs.index')); ?>" class="btn btn-primary btn-lg">View All Articles</a>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- CTA Section -->
<section class="cta-section">
    <div class="container">
        <h2>Ready to Get Started?</h2>
        <p class="mb-4" style="font-size: 1.2rem;">Contact us today to discuss your healthcare needs</p>
        <a href="<?php echo e(route('contact')); ?>" class="btn btn-light btn-lg me-3">Contact Us</a>
        <a href="<?php echo e(route('join')); ?>" class="btn btn-outline-light btn-lg">Join Our Team</a>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Downloads\Extract\Mohawk\Mohawk\workspace\mani\homecare\resources\views/web/home.blade.php ENDPATH**/ ?>