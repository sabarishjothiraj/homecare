<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Contract - <?php echo e($contract->contract_number); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.6;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
        }
        .company-logo {
            max-width: 150px;
            margin-bottom: 10px;
        }
        .contract-title {
            font-size: 24px;
            font-weight: bold;
            margin: 10px 0;
        }
        .contract-number {
            font-size: 14px;
            color: #666;
        }
        .section {
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
            color: #2c3e50;
            border-bottom: 1px solid #ddd;
            padding-bottom: 5px;
        }
        .info-row {
            margin-bottom: 8px;
        }
        .label {
            font-weight: bold;
            display: inline-block;
            width: 150px;
        }
        .value {
            display: inline-block;
        }
        .terms {
            background: #f8f9fa;
            padding: 15px;
            border-left: 3px solid #2c3e50;
            margin: 20px 0;
        }
        .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
        }
        .signature-section {
            margin-top: 40px;
        }
        .signature-box {
            display: inline-block;
            width: 45%;
            text-align: center;
            margin-top: 50px;
        }
        .signature-line {
            border-top: 1px solid #333;
            margin-top: 40px;
            padding-top: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table td {
            padding: 8px;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <?php if($company_logo): ?>
            <img src="<?php echo e(public_path('storage/' . $company_logo)); ?>" alt="<?php echo e($company_name); ?>" class="company-logo">
        <?php endif; ?>
        <div class="contract-title">NURSING SERVICE CONTRACT</div>
        <div class="contract-number">Contract No: <?php echo e($contract->contract_number); ?></div>
        <div>Date: <?php echo e($contract->created_at->format('F d, Y')); ?></div>
    </div>

    <!-- Company Information -->
    <div class="section">
        <div class="section-title">Service Provider</div>
        <div class="info-row"><span class="label">Company Name:</span> <span class="value"><?php echo e($company_name); ?></span></div>
        <div class="info-row"><span class="label">Address:</span> <span class="value"><?php echo e($company_address); ?></span></div>
        <div class="info-row"><span class="label">Phone:</span> <span class="value"><?php echo e($company_phone); ?></span></div>
        <div class="info-row"><span class="label">Email:</span> <span class="value"><?php echo e($company_email); ?></span></div>
    </div>

    <!-- Patient Information -->
    <div class="section">
        <div class="section-title">Patient Information</div>
        <div class="info-row"><span class="label">Name:</span> <span class="value"><?php echo e($contract->patient->name); ?></span></div>
        <div class="info-row"><span class="label">Phone:</span> <span class="value"><?php echo e($contract->patient->phone); ?></span></div>
        <?php if($contract->patient->email): ?>
        <div class="info-row"><span class="label">Email:</span> <span class="value"><?php echo e($contract->patient->email); ?></span></div>
        <?php endif; ?>
        <div class="info-row"><span class="label">Address:</span> <span class="value"><?php echo e($contract->patient->address); ?></span></div>
        <div class="info-row"><span class="label">Community:</span> <span class="value"><?php echo e($contract->patient->community); ?></span></div>
        <div class="info-row"><span class="label">Location:</span> <span class="value"><?php echo e($contract->patient->location); ?></span></div>
    </div>

    <!-- Service Details -->
    <div class="section">
        <div class="section-title">Service Details</div>
        <div class="info-row"><span class="label">Services:</span> <span class="value"><?php echo e($contract->items->pluck('service.name')->filter()->unique()->join(', ') ?: ($contract->service->name ?? 'N/A')); ?></span></div>
        <div class="info-row"><span class="label">Duration Type:</span> <span class="value"><?php echo e(ucfirst($contract->duration_type)); ?></span></div>
        <div class="info-row"><span class="label">Start Date:</span> <span class="value"><?php echo e($contract->start_date->format('F d, Y')); ?></span></div>
        <?php if($contract->end_date): ?>
        <div class="info-row"><span class="label">End Date:</span> <span class="value"><?php echo e($contract->end_date->format('F d, Y')); ?></span></div>
        <?php endif; ?>
        <div class="info-row"><span class="label">Contract Amount:</span> <span class="value">₹<?php echo e(number_format($contract->amount, 2)); ?></span></div>
        <div class="info-row"><span class="label">Payment Method:</span> <span class="value"><?php echo e(ucfirst($contract->payment_method)); ?></span></div>
    </div>

    <!-- Assigned Employees -->
    <div class="section">
        <div class="section-title">Assigned Employees</div>
        <?php if($contract->assignments->count() > 0): ?>
            <table border="1" cellpadding="0" cellspacing="0">
                <thead>
                    <tr style="background: #f3f4f6;">
                        <td><strong>Employee</strong></td>
                        <td><strong>Service</strong></td>
                        <td><strong>Amount</strong></td>
                        <td><strong>Duration</strong></td>
                        <td><strong>Type</strong></td>
                        <td><strong>Notes</strong></td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $contract->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($assignment->employee->getField('name', 'Employee #' . $assignment->employee_id)); ?>

                                <?php if($assignment->employee->getField('phone')): ?>
                                    <br>
                                    <small><?php echo e($assignment->employee->getField('phone')); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($assignment->service->name ?? $assignment->contractItem->service->name ?? ($contract->service->name ?? 'N/A')); ?></td>
                            <td>₹<?php echo e(number_format($assignment->line_amount ?? $assignment->contractItem->amount ?? 0, 2)); ?></td>
                            <td>
                                <?php echo e($assignment->start_date->format('M d, Y')); ?> -
                                <?php echo e($assignment->end_date ? $assignment->end_date->format('M d, Y') : 'Ongoing'); ?>

                            </td>
                            <td>
                                <?php if($assignment->is_emergency_replacement): ?>
                                    Temporary replacement
                                    <?php if($assignment->replacedAssignment): ?>
                                        <br>
                                        <small>For <?php echo e($assignment->replacedAssignment->employee->getField('name', 'N/A')); ?></small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    Primary
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($assignment->assignmentNotes->count() > 0): ?>
                                    <?php $__currentLoopData = $assignment->assignmentNotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        - <?php echo e($note->note); ?><br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php elseif($assignment->getAttribute('notes')): ?>
                                    <?php echo e($assignment->getAttribute('notes')); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No employees assigned at the time of PDF generation.</p>
        <?php endif; ?>
    </div>

    <!-- Terms and Conditions -->
    <div class="section">
        <div class="section-title">Terms and Conditions</div>
        <div class="terms">
            <?php echo nl2br(e($contract->terms)); ?>

        </div>
    </div>

    <!-- Signatures -->
    <div class="signature-section">
        <table>
            <tr>
                <td style="width: 50%;">
                    <div class="signature-box">
                        <div class="signature-line">
                            Service Provider Signature
                        </div>
                        <div style="margin-top: 10px;">
                            <strong><?php echo e($company_name); ?></strong>
                        </div>
                    </div>
                </td>
                <td style="width: 50%;">
                    <div class="signature-box">
                        <div class="signature-line">
                            Patient/Guardian Signature
                        </div>
                        <div style="margin-top: 10px;">
                            <strong><?php echo e($contract->patient->name); ?></strong>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p style="text-align: center; font-size: 10px; color: #666;">
            This is a computer-generated contract. For any queries, please contact <?php echo e($company_email); ?> or <?php echo e($company_phone); ?>.
        </p>
    </div>
</body>
</html>

<?php /**PATH C:\Users\Admin\Downloads\Extract\Mohawk\Mohawk\workspace\mani\homecare\resources\views/pdf/contract.blade.php ENDPATH**/ ?>