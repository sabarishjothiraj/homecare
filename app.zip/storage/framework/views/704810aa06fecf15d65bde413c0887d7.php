<?php $__env->startSection('title', 'Employee Fields'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Employee Fields</h2>
            <p class="text-muted mb-0">Manage dynamic employee form fields</p>
        </div>
        <a href="<?php echo e(route('admin.employee-fields.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Add New Field
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Fields Table -->
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <?php if($fields->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Order</th>
                                <th>Field Name</th>
                                <th>Label</th>
                                <th>Type</th>
                                <th>Required</th>
                                <th>Document</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <span class="badge bg-secondary"><?php echo e($field->display_order); ?></span>
                                </td>
                                <td>
                                    <code><?php echo e($field->name); ?></code>
                                    <?php if($field->is_mandatory): ?>
                                        <span class="badge bg-warning text-dark ms-1" title="Mandatory field - cannot be deleted">
                                            <i class="fas fa-lock"></i> Mandatory
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td><strong><?php echo e($field->label); ?></strong></td>
                                <td>
                                    <span class="badge bg-info"><?php echo e(ucfirst($field->type)); ?></span>
                                </td>
                                <td>
                                    <?php if($field->is_required): ?>
                                        <i class="fas fa-check-circle text-success"></i>
                                    <?php else: ?>
                                        <i class="fas fa-times-circle text-muted"></i>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($field->is_document): ?>
                                        <i class="fas fa-file text-primary"></i>
                                    <?php else: ?>
                                        <i class="fas fa-times text-muted"></i>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($field->is_active): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('admin.employee-fields.edit', $field)); ?>" 
                                           class="btn btn-outline-warning" 
                                           title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <?php if(!$field->is_mandatory): ?>
                                            <form action="<?php echo e(route('admin.employee-fields.destroy', $field)); ?>" 
                                                  method="POST" 
                                                  class="d-inline" 
                                                  onsubmit="return confirm('Are you sure you want to delete this field?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-outline-danger btn-sm" title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-list fa-4x text-muted mb-3 opacity-25"></i>
                    <h5 class="text-muted">No employee fields found</h5>
                    <p class="text-muted">Start by creating your first custom field</p>
                    <a href="<?php echo e(route('admin.employee-fields.create')); ?>" class="btn btn-primary mt-3">
                        <i class="fas fa-plus me-2"></i>Add New Field
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="alert alert-info mt-4">
        <i class="fas fa-info-circle me-2"></i>
        <strong>Note:</strong> Mandatory fields (marked with <i class="fas fa-lock"></i>) are system-required and cannot be deleted. You can only activate/deactivate them.
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Downloads\Extract\Mohawk\Mohawk\workspace\mani\homecare\resources\views/admin/employee-fields/index.blade.php ENDPATH**/ ?>