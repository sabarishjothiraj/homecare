<?php $__env->startSection('title', 'Assignments'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Assignments</h2>
            <p class="text-muted mb-0">Manage employee-contract assignments</p>
        </div>
        <a href="<?php echo e(route('admin.assignments.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Create New Assignment
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Filters -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.assignments.index')); ?>" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Contract</label>
                    <select name="contract_id" class="form-select">
                        <option value="">All Contracts</option>
                        <?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($contract->id); ?>" <?php echo e(request('contract_id') == $contract->id ? 'selected' : ''); ?>>
                                <?php echo e($contract->contract_number); ?> - <?php echo e($contract->patient->name ?? 'N/A'); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Employee</label>
                    <select name="employee_id" class="form-select">
                        <option value="">All Employees</option>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($employee->id); ?>" <?php echo e(request('employee_id') == $employee->id ? 'selected' : ''); ?>>
                                <?php echo e($employee->getField('name', 'Employee #' . $employee->id)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="">All Status</option>
                        <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i>Filter
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Assignments Table -->
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <?php if($assignments->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Contract</th>
                                <th>Patient</th>
                                <th>Employee</th>
                                <th>Service</th>
                                <th>Duration</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong>#<?php echo e($assignment->id); ?></strong></td>
                                <td>
                                    <strong class="text-primary"><?php echo e($assignment->contract->contract_number ?? 'N/A'); ?></strong>
                                    <?php if($assignment->is_emergency_replacement): ?>
                                        <br><span class="badge bg-danger">Emergency</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary bg-opacity-10 rounded-circle p-2 me-2">
                                            <i class="fas fa-user text-primary"></i>
                                        </div>
                                        <div>
                                            <strong><?php echo e($assignment->contract->patient->name ?? 'N/A'); ?></strong>
                                            <br>
                                            <small class="text-muted"><?php echo e($assignment->contract->patient->community ?? ''); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-success bg-opacity-10 rounded-circle p-2 me-2">
                                            <i class="fas fa-user-nurse text-success"></i>
                                        </div>
                                        <div>
                                            <strong><?php echo e($assignment->employee->getField('name', 'N/A')); ?></strong>
                                            <br>
                                            <small class="text-muted"><?php echo e($assignment->employee->getField('phone', '')); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo e($assignment->contract->service->name ?? 'N/A'); ?></td>
                                <td>
                                    <small>
                                        <strong>Start:</strong> <?php echo e($assignment->start_date->format('M d, Y')); ?><br>
                                        <strong>End:</strong> <?php echo e($assignment->end_date ? $assignment->end_date->format('M d, Y') : 'Ongoing'); ?>

                                    </small>
                                </td>
                                <td>
                                    <?php if($assignment->is_active): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('admin.assignments.show', $assignment)); ?>" class="btn btn-outline-primary" title="View">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.assignments.edit', $assignment)); ?>" class="btn btn-outline-warning" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.assignments.destroy', $assignment)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this assignment?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-outline-danger btn-sm" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="card-footer bg-white">
                    <?php echo e($assignments->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-tasks fa-4x text-muted mb-3 opacity-25"></i>
                    <h5 class="text-muted">No assignments found</h5>
                    <p class="text-muted">Start by creating your first assignment</p>
                    <a href="<?php echo e(route('admin.assignments.create')); ?>" class="btn btn-primary mt-3">
                        <i class="fas fa-plus me-2"></i>Create New Assignment
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Sabarish\Mohawk\workspace\mani\homenursing\resources\views/admin/assignments/index.blade.php ENDPATH**/ ?>