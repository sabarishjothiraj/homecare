<?php $__env->startSection('title', 'Our Services'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .page-header {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        color: white;
        padding: 80px 0 60px;
        text-align: center;
    }
    
    .page-header h1 {
        font-size: 3rem;
        font-weight: 700;
        margin-bottom: 1rem;
    }
    
    .service-detail-card {
        background: white;
        border-radius: 15px;
        padding: 2.5rem;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        transition: all 0.3s;
        height: 100%;
        border-top: 4px solid var(--primary-color);
    }
    
    .service-detail-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    }
    
    .service-icon-large {
        font-size: 4rem;
        color: var(--primary-color);
        margin-bottom: 1.5rem;
    }
    
    .service-detail-card h3 {
        color: var(--dark-color);
        font-weight: 600;
        margin-bottom: 1rem;
    }
    
    .service-detail-card p {
        color: #64748b;
        line-height: 1.8;
        margin: 0;
    }
    
    .no-services {
        text-align: center;
        padding: 4rem 0;
    }
    
    .no-services i {
        font-size: 5rem;
        color: #cbd5e1;
        margin-bottom: 1.5rem;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <h1>Our Services</h1>
        <p class="lead">Comprehensive healthcare solutions tailored to your needs</p>
    </div>
</section>

<!-- Services List -->
<section class="py-5">
    <div class="container">
        <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="row mb-4">
            <div class="col-12">
                <div class="service-detail-card">
                    <div class="row align-items-center">
                        <div class="col-lg-2 col-md-3 text-center mb-3 mb-md-0">
                            <div class="service-icon-large">
                                <i class="<?php echo e($service->icon ?: 'fas fa-heartbeat'); ?>"></i>
                            </div>
                        </div>
                        <div class="col-lg-10 col-md-9">
                            <h3><?php echo e($service->name); ?></h3>
                            <p><?php echo e($service->description); ?></p>
                            <?php if($service->image): ?>
                            <div class="mt-3">
                                <img src="<?php echo e(asset('storage/' . $service->image)); ?>" alt="<?php echo e($service->name); ?>" class="img-fluid rounded" style="max-height: 300px;">
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="no-services">
            <i class="fas fa-hospital"></i>
            <h3>No Services Available</h3>
            <p class="text-muted">We're currently updating our services. Please check back soon or contact us for more information.</p>
            <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary mt-3">Contact Us</a>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- CTA Section -->
<?php if($services->count() > 0): ?>
<section class="py-5 bg-light">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h2 class="mb-3">Need a Customized Care Plan?</h2>
                <p class="text-muted mb-0">Our team can create a personalized healthcare solution based on your specific requirements.</p>
            </div>
            <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
                <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary btn-lg">Get in Touch</a>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Why Choose Our Services -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Why Choose Our Services</h2>
            <p class="section-subtitle">Quality care you can trust</p>
        </div>
        <div class="row g-4">
            <div class="col-lg-3 col-md-6 text-center">
                <i class="fas fa-user-nurse fa-4x text-primary mb-3"></i>
                <h5>Certified Professionals</h5>
                <p class="text-muted">All our nurses are certified and experienced</p>
            </div>
            <div class="col-lg-3 col-md-6 text-center">
                <i class="fas fa-clipboard-check fa-4x text-primary mb-3"></i>
                <h5>Personalized Care</h5>
                <p class="text-muted">Customized care plans for each patient</p>
            </div>
            <div class="col-lg-3 col-md-6 text-center">
                <i class="fas fa-headset fa-4x text-primary mb-3"></i>
                <h5>24/7 Support</h5>
                <p class="text-muted">Round-the-clock assistance and monitoring</p>
            </div>
            <div class="col-lg-3 col-md-6 text-center">
                <i class="fas fa-hand-holding-medical fa-4x text-primary mb-3"></i>
                <h5>Compassionate Care</h5>
                <p class="text-muted">Treating patients with dignity and respect</p>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Downloads\Extract\Mohawk\Mohawk\workspace\mani\homecare\resources\views/web/services.blade.php ENDPATH**/ ?>