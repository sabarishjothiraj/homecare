<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Dashboard</h2>
            <p class="text-muted mb-0">Welcome back, <?php echo e(auth()->user()->name); ?>!</p>
        </div>
        <div class="text-muted">
            <i class="fas fa-calendar-alt me-2"></i><?php echo e(now()->format('l, F j, Y')); ?>

        </div>
    </div>

    <!-- Statistics Cards Row 1 -->
    <div class="row g-3 mb-4">
        <!-- Total Patients -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted mb-1 small">Total Patients</p>
                            <h3 class="mb-0"><?php echo e($totalPatients); ?></h3>
                            <small class="text-success">
                                <i class="fas fa-check-circle me-1"></i><?php echo e($activePatients); ?> Active
                            </small>
                        </div>
                        <div class="bg-primary bg-opacity-10 p-3 rounded">
                            <i class="fas fa-user-injured fa-2x text-primary"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Employees -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted mb-1 small">Total Employees</p>
                            <h3 class="mb-0"><?php echo e($totalEmployees); ?></h3>
                            <small class="text-success">
                                <i class="fas fa-check-circle me-1"></i><?php echo e($activeEmployees); ?> Active
                            </small>
                        </div>
                        <div class="bg-success bg-opacity-10 p-3 rounded">
                            <i class="fas fa-user-nurse fa-2x text-success"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Active Contracts -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted mb-1 small">Active Contracts</p>
                            <h3 class="mb-0"><?php echo e($contractStats['active'] ?? 0); ?></h3>
                            <small class="text-warning">
                                <i class="fas fa-clock me-1"></i><?php echo e($contractStats['pending'] ?? 0); ?> Pending
                            </small>
                        </div>
                        <div class="bg-info bg-opacity-10 p-3 rounded">
                            <i class="fas fa-file-contract fa-2x text-info"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Revenue -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted mb-1 small">Total Revenue</p>
                            <h3 class="mb-0">₹<?php echo e(number_format($totalRevenue, 0)); ?></h3>
                            <small class="text-info">
                                <i class="fas fa-calendar-week me-1"></i>₹<?php echo e(number_format($last7DaysRevenue, 0)); ?> (7d)
                            </small>
                        </div>
                        <div class="bg-warning bg-opacity-10 p-3 rounded">
                            <i class="fas fa-rupee-sign fa-2x text-warning"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards Row 2 -->
    <div class="row g-3 mb-4">
        <!-- Pending Employees -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center">
                    <i class="fas fa-user-clock fa-2x text-warning mb-2"></i>
                    <h4 class="mb-0"><?php echo e($pendingEmployees); ?></h4>
                    <small class="text-muted">Pending Employees</small>
                </div>
            </div>
        </div>

        <!-- Inactive Employees -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center">
                    <i class="fas fa-user-slash fa-2x text-danger mb-2"></i>
                    <h4 class="mb-0"><?php echo e($inactiveEmployees); ?></h4>
                    <small class="text-muted">Inactive Employees</small>
                </div>
            </div>
        </div>

        <!-- Expiring Contracts -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center">
                    <i class="fas fa-exclamation-triangle fa-2x text-danger mb-2"></i>
                    <h4 class="mb-0"><?php echo e($expiringContracts->count()); ?></h4>
                    <small class="text-muted">Expiring Soon</small>
                </div>
            </div>
        </div>

        <!-- 30 Days Revenue -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center">
                    <i class="fas fa-chart-line fa-2x text-success mb-2"></i>
                    <h4 class="mb-0">₹<?php echo e(number_format($last30DaysRevenue, 0)); ?></h4>
                    <small class="text-muted">Last 30 Days</small>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <!-- Monthly Revenue Chart -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Monthly Revenue (Last 6 Months)</h5>
                </div>
                <div class="card-body">
                    <canvas id="revenueChart" height="80"></canvas>
                </div>
            </div>
        </div>

        <!-- Contract Status Distribution -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Contract Status</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span>Active</span>
                            <strong class="text-success"><?php echo e($contractStats['active'] ?? 0); ?></strong>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar bg-success" style="width: <?php echo e(($contractStats['total'] ?? 0) > 0 ? (($contractStats['active'] ?? 0) / ($contractStats['total'] ?? 0) * 100) : 0); ?>%"></div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span>Pending</span>
                            <strong class="text-warning"><?php echo e($contractStats['pending'] ?? 0); ?></strong>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar bg-warning" style="width: <?php echo e(($contractStats['total'] ?? 0) > 0 ? (($contractStats['pending'] ?? 0) / ($contractStats['total'] ?? 0) * 100) : 0); ?>%"></div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span>Completed</span>
                            <strong class="text-info"><?php echo e($contractStats['completed'] ?? 0); ?></strong>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar bg-info" style="width: <?php echo e(($contractStats['total'] ?? 0) > 0 ? (($contractStats['completed'] ?? 0) / ($contractStats['total'] ?? 0) * 100) : 0); ?>%"></div>
                        </div>
                    </div>
                    <div>
                        <div class="d-flex justify-content-between mb-1">
                            <span>Cancelled</span>
                            <strong class="text-danger"><?php echo e($contractStats['cancelled'] ?? 0); ?></strong>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar bg-danger" style="width: <?php echo e(($contractStats['total'] ?? 0) > 0 ? (($contractStats['cancelled'] ?? 0) / ($contractStats['total'] ?? 0) * 100) : 0); ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <!-- Recent Contracts -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-file-contract me-2"></i>Recent Contracts</h5>
                    <a href="<?php echo e(route('admin.contracts.index')); ?>" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <?php if($recentContracts->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Patient</th>
                                        <th>Service</th>
                                        <th>Status</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $recentContracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($contract->patient->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($contract->service->name ?? 'N/A'); ?></td>
                                        <td>
                                            <?php if($contract->status === 'active'): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php elseif($contract->status === 'pending'): ?>
                                                <span class="badge bg-warning">Pending</span>
                                            <?php elseif($contract->status === 'completed'): ?>
                                                <span class="badge bg-info">Completed</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger"><?php echo e(ucfirst($contract->status)); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>₹<?php echo e(number_format($contract->total_amount, 0)); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-inbox fa-3x mb-3 opacity-25"></i>
                            <p>No contracts yet</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Expiring Contracts -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-exclamation-triangle me-2 text-danger"></i>Expiring Soon</h5>
                    <a href="<?php echo e(route('admin.contracts.index')); ?>" class="btn btn-sm btn-outline-danger">View All</a>
                </div>
                <div class="card-body p-0">
                    <?php if($expiringContracts->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Patient</th>
                                        <th>Service</th>
                                        <th>End Date</th>
                                        <th>Days Left</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $expiringContracts->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($contract->patient->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($contract->service->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($contract->end_date->format('M d, Y')); ?></td>
                                        <td>
                                            <span class="badge bg-danger">
                                                <?php echo e($contract->end_date->diffInDays(now())); ?> days
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-check-circle fa-3x mb-3 opacity-25"></i>
                            <p>No expiring contracts</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3">
        <!-- Recent Contact Queries -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-envelope me-2"></i>Recent Queries</h5>
                    <a href="<?php echo e(route('admin.contact-queries.index')); ?>" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <?php if($recentQueries->count() > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php $__currentLoopData = $recentQueries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('admin.contact-queries.show', $query)); ?>" class="list-group-item list-group-item-action">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?php echo e($query->name); ?></h6>
                                        <p class="mb-1 small text-muted"><?php echo e(Str::limit($query->message, 60)); ?></p>
                                        <small class="text-muted"><?php echo e($query->created_at->diffForHumans()); ?></small>
                                    </div>
                                    <span class="badge bg-primary">New</span>
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-inbox fa-3x mb-3 opacity-25"></i>
                            <p>No new queries</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Recent Join Requests -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-user-plus me-2"></i>Join Requests</h5>
                    <a href="<?php echo e(route('admin.join-requests.index')); ?>" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <?php if($recentJoinRequests->count() > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php $__currentLoopData = $recentJoinRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('admin.join-requests.show', $request)); ?>" class="list-group-item list-group-item-action">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?php echo e($request->name); ?></h6>
                                        <p class="mb-1 small text-muted"><?php echo e($request->email); ?> • <?php echo e($request->phone); ?></p>
                                        <small class="text-muted"><?php echo e($request->created_at->diffForHumans()); ?></small>
                                    </div>
                                    <span class="badge bg-success">New</span>
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-inbox fa-3x mb-3 opacity-25"></i>
                            <p>No new join requests</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
    // Monthly Revenue Chart
    const ctx = document.getElementById('revenueChart');
    const monthlyData = <?php echo json_encode($monthlyRevenue, 15, 512) ?>;

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: monthlyData.map(item => item.month),
            datasets: [{
                label: 'Revenue (₹)',
                data: monthlyData.map(item => item.revenue),
                backgroundColor: 'rgba(52, 152, 219, 0.8)',
                borderColor: 'rgba(52, 152, 219, 1)',
                borderWidth: 1,
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return '₹' + context.parsed.y.toLocaleString('en-IN');
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '₹' + value.toLocaleString('en-IN');
                        }
                    }
                }
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Downloads\Extract\Mohawk\Mohawk\workspace\mani\homecare\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>