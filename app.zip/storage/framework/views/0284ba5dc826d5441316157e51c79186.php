<?php $__env->startSection('title', 'Join With Us'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .page-header {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        color: white;
        padding: 80px 0 60px;
        text-align: center;
    }
    
    .page-header h1 {
        font-size: 3rem;
        font-weight: 700;
        margin-bottom: 1rem;
    }
    
    .benefit-card {
        background: white;
        border-radius: 15px;
        padding: 2rem;
        text-align: center;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        height: 100%;
        transition: all 0.3s;
    }
    
    .benefit-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    }
    
    .benefit-icon {
        font-size: 3rem;
        color: var(--primary-color);
        margin-bottom: 1rem;
    }
    
    .form-control, .form-select {
        border-radius: 10px;
        padding: 0.75rem 1rem;
        border: 2px solid #e2e8f0;
    }
    
    .form-control:focus, .form-select:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 0.2rem rgba(37, 99, 235, 0.1);
    }
    
    .form-label {
        font-weight: 500;
        color: var(--dark-color);
        margin-bottom: 0.5rem;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <h1>Join Our Team</h1>
        <p class="lead">Be part of a dedicated team making a difference in people's lives</p>
    </div>
</section>

<!-- Benefits Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Why Join Us</h2>
            <p class="section-subtitle">Benefits of working with our team</p>
        </div>
        
        <?php if($joinBenefits): ?>
        <div class="mb-5">
            <div class="card border-0 shadow-sm" style="border-radius: 15px;">
                <div class="card-body p-4">
                    <?php echo nl2br(e($joinBenefits)); ?>

                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="row g-4 mb-5">
            <div class="col-lg-3 col-md-6">
                <div class="benefit-card">
                    <div class="benefit-icon">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <h5>Competitive Pay</h5>
                    <p class="text-muted">Attractive compensation packages</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="benefit-card">
                    <div class="benefit-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <h5>Flexible Schedule</h5>
                    <p class="text-muted">Work-life balance options</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="benefit-card">
                    <div class="benefit-icon">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <h5>Training & Growth</h5>
                    <p class="text-muted">Continuous learning opportunities</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="benefit-card">
                    <div class="benefit-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h5>Supportive Team</h5>
                    <p class="text-muted">Collaborative work environment</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Application Form -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card border-0 shadow-lg" style="border-radius: 15px;">
                    <div class="card-body p-5">
                        <h2 class="text-center mb-4">Application Form</h2>
                        <p class="text-center text-muted mb-4">Fill out the form below to apply for a position with us</p>
                        
                        <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php endif; ?>
                        
                        <form action="<?php echo e(route('join.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            
                            <div class="row">
                                <?php $__currentLoopData = $employeeFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-<?php echo e(in_array($field->type, ['textarea']) ? '12' : '6'); ?> mb-3">
                                    <label for="<?php echo e($field->name); ?>" class="form-label">
                                        <?php echo e($field->label); ?>

                                        <?php if($field->is_required): ?>
                                        <span class="text-danger">*</span>
                                        <?php endif; ?>
                                    </label>
                                    
                                    <?php if($field->type === 'textarea'): ?>
                                    <textarea class="form-control <?php $__errorArgs = [$field->name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                              id="<?php echo e($field->name); ?>"
                                              name="<?php echo e($field->name); ?>"
                                              rows="4"
                                              <?php echo e($field->is_required ? 'required' : ''); ?>><?php echo e(old($field->name)); ?></textarea>

                                    <?php elseif($field->type === 'select' && $field->options): ?>
                                    <select class="form-select <?php $__errorArgs = [$field->name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="<?php echo e($field->name); ?>"
                                            name="<?php echo e($field->name); ?>"
                                            <?php echo e($field->is_required ? 'required' : ''); ?>>
                                        <option value="">Select <?php echo e($field->label); ?></option>
                                        <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($option); ?>" <?php echo e(old($field->name) == $option ? 'selected' : ''); ?>>
                                            <?php echo e($option); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php elseif($field->type === 'date'): ?>
                                    <input type="date"
                                           class="form-control <?php $__errorArgs = [$field->name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="<?php echo e($field->name); ?>"
                                           name="<?php echo e($field->name); ?>"
                                           value="<?php echo e(old($field->name)); ?>"
                                           <?php echo e($field->is_required ? 'required' : ''); ?>>

                                    <?php elseif($field->type === 'number'): ?>
                                    <input type="number"
                                           class="form-control <?php $__errorArgs = [$field->name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="<?php echo e($field->name); ?>"
                                           name="<?php echo e($field->name); ?>"
                                           value="<?php echo e(old($field->name)); ?>"
                                           <?php echo e($field->is_required ? 'required' : ''); ?>>

                                    <?php elseif($field->type === 'email'): ?>
                                    <input type="email"
                                           class="form-control <?php $__errorArgs = [$field->name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="<?php echo e($field->name); ?>"
                                           name="<?php echo e($field->name); ?>"
                                           value="<?php echo e(old($field->name)); ?>"
                                           <?php echo e($field->is_required ? 'required' : ''); ?>>

                                    <?php elseif($field->type === 'phone'): ?>
                                    <input type="tel"
                                           class="form-control <?php $__errorArgs = [$field->name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="<?php echo e($field->name); ?>"
                                           name="<?php echo e($field->name); ?>"
                                           value="<?php echo e(old($field->name)); ?>"
                                           <?php echo e($field->is_required ? 'required' : ''); ?>>

                                    <?php else: ?>
                                    <input type="text"
                                           class="form-control <?php $__errorArgs = [$field->name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="<?php echo e($field->name); ?>"
                                           name="<?php echo e($field->name); ?>"
                                           value="<?php echo e(old($field->name)); ?>"
                                           <?php echo e($field->is_required ? 'required' : ''); ?>>
                                    <?php endif; ?>

                                    <?php $__errorArgs = [$field->name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-primary btn-lg px-5">
                                    <i class="fas fa-paper-plane me-2"></i>Submit Application
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Requirements Section -->
<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <h2 class="text-center mb-4">Requirements</h2>
                <div class="card border-0 shadow-sm" style="border-radius: 15px;">
                    <div class="card-body p-4">
                        <ul class="list-unstyled mb-0">
                            <li class="mb-3"><i class="fas fa-check-circle text-success me-2"></i> Valid nursing license or certification</li>
                            <li class="mb-3"><i class="fas fa-check-circle text-success me-2"></i> Minimum 2 years of experience in healthcare</li>
                            <li class="mb-3"><i class="fas fa-check-circle text-success me-2"></i> Excellent communication and interpersonal skills</li>
                            <li class="mb-3"><i class="fas fa-check-circle text-success me-2"></i> Compassionate and patient-centered approach</li>
                            <li class="mb-3"><i class="fas fa-check-circle text-success me-2"></i> Ability to work independently and as part of a team</li>
                            <li class="mb-0"><i class="fas fa-check-circle text-success me-2"></i> Clean background check and references</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Sabarish\Mohawk\workspace\mani\homenursing\resources\views/web/join.blade.php ENDPATH**/ ?>