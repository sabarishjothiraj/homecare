<?php
    $isEdit = isset($employee) && $employee;
    $fieldData = $isEdit ? ($employee->field_data ?? []) : [];

    $presentAddress = old('present_address', $fieldData['present_address'] ?? []);
    $permanentAddress = old('permanent_address', $fieldData['permanent_address'] ?? []);

    $experienceItems = old('experience', $fieldData['experience'] ?? []);
    if (empty($experienceItems)) {
        $experienceItems = [[]];
    }

    $specialization = old('specialization', $fieldData['specialization'] ?? '');

    $emergencyContacts = old('emergency_contacts', $fieldData['emergency_contacts'] ?? []);
    if (empty($emergencyContacts)) {
        $emergencyContacts = [[], []];
    }
    while (count($emergencyContacts) < 2) {
        $emergencyContacts[] = [];
    }

    $documents = old('documents', $fieldData['documents'] ?? []);
    if (empty($documents)) {
        $documents = [[]];
    }

    $employeeImagePath = $fieldData['employee_image_path'] ?? null;
    $employeeImageUrl = $employeeImagePath ? Storage::url($employeeImagePath) : null;

    $sameAsPresent = old('same_as_present_address', false);

    $employmentTypeOptions = [
        'full_time' => 'Full Time',
        'part_time' => 'Part Time',
        'contract' => 'Contract',
        'internship' => 'Internship',
        'freelance' => 'Freelance',
    ];
?>

<form action="<?php echo e($formAction); ?>" method="POST" enctype="multipart/form-data" data-ajax="true">
    <?php echo csrf_field(); ?>
    <?php if($formMethod !== 'POST'): ?>
        <?php echo method_field($formMethod); ?>
    <?php endif; ?>

    <div class="row g-3 mb-2">
        <div class="col-md-6">
            <label for="first_name" class="form-label">First Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="first_name" name="first_name" value="<?php echo e(old('first_name', $isEdit ? $employee->first_name : ($fieldData['first_name'] ?? ''))); ?>" required>
            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-md-6">
            <label for="last_name" class="form-label">Last Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="last_name" name="last_name" value="<?php echo e(old('last_name', $isEdit ? $employee->last_name : ($fieldData['last_name'] ?? ''))); ?>" required>
            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-md-6">
            <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e(old('email', $isEdit ? $employee->email : ($fieldData['email'] ?? ''))); ?>" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-md-6">
            <label for="phone" class="form-label">Phone <span class="text-danger">*</span></label>
            <input type="tel" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone" name="phone" value="<?php echo e(old('phone', $isEdit ? $employee->phone : ($fieldData['phone'] ?? ''))); ?>" required>
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-md-6">
            <label for="alternate_phone" class="form-label">Alternate Phone</label>
            <input type="tel" class="form-control <?php $__errorArgs = ['alternate_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alternate_phone" name="alternate_phone" value="<?php echo e(old('alternate_phone', $isEdit ? $employee->alternate_phone : ($fieldData['alternate_phone'] ?? ''))); ?>">
            <?php $__errorArgs = ['alternate_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-md-6">
            <label for="service_ids" class="form-label">Employee Categories <span class="text-danger">*</span></label>
            <?php
                $selectedServiceIds = collect(old('service_ids', $isEdit ? $employee->services->pluck('id')->all() : []));
            ?>
            <select class="form-select <?php $__errorArgs = ['service_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="service_ids" name="service_ids[]" multiple required>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($service->id); ?>" <?php echo e($selectedServiceIds->contains($service->id) ? 'selected' : ''); ?>><?php echo e($service->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small class="text-muted">Hold Ctrl (Windows) or Cmd (Mac) to select multiple categories.</small>
            <?php $__errorArgs = ['service_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['service_ids.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <hr class="my-4">

    <div class="row g-3 mb-2">
        <div class="col-md-6">
            <label for="caste_id" class="form-label">Caste</label>
            <select class="form-select <?php $__errorArgs = ['caste_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="caste_id" name="caste_id">
                <option value="">Select Caste</option>
                <?php $__currentLoopData = $castes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($caste->id); ?>" <?php echo e((string) old('caste_id', $isEdit ? $employee->caste_id : '') === (string) $caste->id ? 'selected' : ''); ?>>
                        <?php echo e($caste->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['caste_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-md-6">
            <label for="subcaste" class="form-label">Subcaste</label>
            <input type="text"
                   class="form-control <?php $__errorArgs = ['subcaste'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   id="subcaste"
                   name="subcaste"
                   value="<?php echo e(old('subcaste', $isEdit ? $employee->subcaste : '')); ?>"
                   maxlength="100">
            <?php $__errorArgs = ['subcaste'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <hr class="my-4">
    <h6 class="mb-3"><i class="fas fa-map-marker-alt me-2"></i>Present Address</h6>
    <div class="row g-3">
        <div class="col-md-6">
            <label class="form-label">Address Line 1 <span class="text-danger">*</span></label>
            <input type="text" class="form-control <?php $__errorArgs = ['present_address.address_line1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="present_address[address_line1]" value="<?php echo e($presentAddress['address_line1'] ?? ''); ?>" required>
            <?php $__errorArgs = ['present_address.address_line1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label class="form-label">Address Line 2</label>
            <input type="text" class="form-control <?php $__errorArgs = ['present_address.address_line2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="present_address[address_line2]" value="<?php echo e($presentAddress['address_line2'] ?? ''); ?>">
            <?php $__errorArgs = ['present_address.address_line2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label class="form-label">Area</label>
            <input type="text" class="form-control <?php $__errorArgs = ['present_address.area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="present_address[area]" value="<?php echo e($presentAddress['area'] ?? ''); ?>">
            <?php $__errorArgs = ['present_address.area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label class="form-label">Landmark</label>
            <input type="text" class="form-control <?php $__errorArgs = ['present_address.landmark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="present_address[landmark]" value="<?php echo e($presentAddress['landmark'] ?? ''); ?>">
            <?php $__errorArgs = ['present_address.landmark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label class="form-label">City <span class="text-danger">*</span></label>
            <input type="text" class="form-control <?php $__errorArgs = ['present_address.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="present_address[city]" value="<?php echo e($presentAddress['city'] ?? ''); ?>" required>
            <?php $__errorArgs = ['present_address.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label class="form-label">State <span class="text-danger">*</span></label>
            <input type="text" class="form-control <?php $__errorArgs = ['present_address.state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="present_address[state]" value="<?php echo e($presentAddress['state'] ?? ''); ?>" required>
            <?php $__errorArgs = ['present_address.state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label class="form-label">Country <span class="text-danger">*</span></label>
            <input type="text" class="form-control <?php $__errorArgs = ['present_address.country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="present_address[country]" value="<?php echo e($presentAddress['country'] ?? ''); ?>" required>
            <?php $__errorArgs = ['present_address.country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label class="form-label">Pincode <span class="text-danger">*</span></label>
            <input type="number" class="form-control <?php $__errorArgs = ['present_address.pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="present_address[pincode]" value="<?php echo e($presentAddress['pincode'] ?? ''); ?>" required>
            <?php $__errorArgs = ['present_address.pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <hr class="my-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="mb-0"><i class="fas fa-map me-2"></i>Permanent Address</h6>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" id="same-as-present-address" name="same_as_present_address" value="1" <?php echo e($sameAsPresent ? 'checked' : ''); ?>>
            <label class="form-check-label" for="same-as-present-address">Same as Present Address</label>
        </div>
    </div>

    <div class="row g-3" id="permanent-address-wrapper">
        <div class="col-md-6">
            <label class="form-label">Address Line 1 <span class="text-danger">*</span></label>
            <input type="text" class="form-control <?php $__errorArgs = ['permanent_address.address_line1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="permanent_address[address_line1]" value="<?php echo e($permanentAddress['address_line1'] ?? ''); ?>" required>
            <?php $__errorArgs = ['permanent_address.address_line1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label class="form-label">Address Line 2</label>
            <input type="text" class="form-control <?php $__errorArgs = ['permanent_address.address_line2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="permanent_address[address_line2]" value="<?php echo e($permanentAddress['address_line2'] ?? ''); ?>">
            <?php $__errorArgs = ['permanent_address.address_line2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label class="form-label">Area</label>
            <input type="text" class="form-control <?php $__errorArgs = ['permanent_address.area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="permanent_address[area]" value="<?php echo e($permanentAddress['area'] ?? ''); ?>">
            <?php $__errorArgs = ['permanent_address.area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label class="form-label">Landmark</label>
            <input type="text" class="form-control <?php $__errorArgs = ['permanent_address.landmark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="permanent_address[landmark]" value="<?php echo e($permanentAddress['landmark'] ?? ''); ?>">
            <?php $__errorArgs = ['permanent_address.landmark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label class="form-label">City <span class="text-danger">*</span></label>
            <input type="text" class="form-control <?php $__errorArgs = ['permanent_address.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="permanent_address[city]" value="<?php echo e($permanentAddress['city'] ?? ''); ?>" required>
            <?php $__errorArgs = ['permanent_address.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label class="form-label">State <span class="text-danger">*</span></label>
            <input type="text" class="form-control <?php $__errorArgs = ['permanent_address.state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="permanent_address[state]" value="<?php echo e($permanentAddress['state'] ?? ''); ?>" required>
            <?php $__errorArgs = ['permanent_address.state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label class="form-label">Country <span class="text-danger">*</span></label>
            <input type="text" class="form-control <?php $__errorArgs = ['permanent_address.country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="permanent_address[country]" value="<?php echo e($permanentAddress['country'] ?? ''); ?>" required>
            <?php $__errorArgs = ['permanent_address.country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <label class="form-label">Pincode <span class="text-danger">*</span></label>
            <input type="number" class="form-control <?php $__errorArgs = ['permanent_address.pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="permanent_address[pincode]" value="<?php echo e($permanentAddress['pincode'] ?? ''); ?>" required>
            <?php $__errorArgs = ['permanent_address.pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <hr class="my-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="mb-0"><i class="fas fa-briefcase me-2"></i>Experience</h6>
        <button type="button" class="btn btn-sm btn-outline-primary" id="add-experience-btn">
            <i class="fas fa-plus me-1"></i>Add Experience
        </button>
    </div>
    <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger small mb-2"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div id="experience-container" data-next-index="<?php echo e(count($experienceItems)); ?>">
        <?php $__currentLoopData = $experienceItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card border mb-3 experience-item" data-index="<?php echo e($index); ?>">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="mb-0">Experience #<?php echo e($loop->iteration); ?></h6>
                        <button type="button" class="btn btn-sm btn-outline-danger remove-experience-btn">Remove</button>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Company Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ["experience.$index.company_name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="experience[<?php echo e($index); ?>][company_name]" value="<?php echo e($experience['company_name'] ?? ''); ?>">
                            <?php $__errorArgs = ["experience.$index.company_name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Job Title</label>
                            <input type="text" class="form-control <?php $__errorArgs = ["experience.$index.job_title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="experience[<?php echo e($index); ?>][job_title]" value="<?php echo e($experience['job_title'] ?? ''); ?>">
                            <?php $__errorArgs = ["experience.$index.job_title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Employment Type</label>
                            <select class="form-select <?php $__errorArgs = ["experience.$index.employment_type"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="experience[<?php echo e($index); ?>][employment_type]">
                                <option value="">Select Type</option>
                                <?php $__currentLoopData = $employmentTypeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>" <?php echo e(($experience['employment_type'] ?? '') === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ["experience.$index.employment_type"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Start Date <span class="text-danger">*</span></label>
                            <input type="date" class="form-control <?php $__errorArgs = ["experience.$index.start_date"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="experience[<?php echo e($index); ?>][start_date]" value="<?php echo e($experience['start_date'] ?? ''); ?>">
                            <?php $__errorArgs = ["experience.$index.start_date"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">End Date</label>
                            <input type="date" class="form-control experience-end-date <?php $__errorArgs = ["experience.$index.end_date"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="experience[<?php echo e($index); ?>][end_date]" value="<?php echo e($experience['end_date'] ?? ''); ?>" <?php echo e(!empty($experience['currently_working']) ? 'disabled' : ''); ?>>
                            <?php $__errorArgs = ["experience.$index.end_date"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="form-check mt-2">
                                <input type="checkbox" class="form-check-input currently-working-checkbox" id="experience-currently-working-<?php echo e($index); ?>" name="experience[<?php echo e($index); ?>][currently_working]" value="1" <?php echo e(!empty($experience['currently_working']) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="experience-currently-working-<?php echo e($index); ?>">Currently Working</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Last Salary</label>
                            <input type="number" step="0.01" class="form-control <?php $__errorArgs = ["experience.$index.last_salary"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="experience[<?php echo e($index); ?>][last_salary]" value="<?php echo e($experience['last_salary'] ?? ''); ?>">
                            <?php $__errorArgs = ["experience.$index.last_salary"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Reason For Leaving</label>
                            <input type="text" class="form-control <?php $__errorArgs = ["experience.$index.reason_for_leaving"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="experience[<?php echo e($index); ?>][reason_for_leaving]" value="<?php echo e($experience['reason_for_leaving'] ?? ''); ?>">
                            <?php $__errorArgs = ["experience.$index.reason_for_leaving"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Responsibilities</label>
                            <textarea class="form-control <?php $__errorArgs = ["experience.$index.responsibilities"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3" name="experience[<?php echo e($index); ?>][responsibilities]"><?php echo e($experience['responsibilities'] ?? ''); ?></textarea>
                            <?php $__errorArgs = ["experience.$index.responsibilities"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <hr class="my-4">
    <h6 class="mb-3"><i class="fas fa-star me-2"></i>Specialization</h6>
    <textarea class="form-control <?php $__errorArgs = ['specialization'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="specialization" rows="4" placeholder="Write specialization details..."><?php echo e($specialization); ?></textarea>
    <?php $__errorArgs = ['specialization'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback d-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <hr class="my-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="mb-0"><i class="fas fa-phone-alt me-2"></i>Emergency Contacts (Min 2)</h6>
        <button type="button" class="btn btn-sm btn-outline-primary" id="add-emergency-contact-btn">
            <i class="fas fa-plus me-1"></i>Add Contact
        </button>
    </div>
    <?php $__errorArgs = ['emergency_contacts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger small mb-2"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div id="emergency-contacts-container" data-next-index="<?php echo e(count($emergencyContacts)); ?>">
        <?php $__currentLoopData = $emergencyContacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card border mb-3 emergency-contact-item" data-index="<?php echo e($index); ?>">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="mb-0">Contact #<?php echo e($loop->iteration); ?></h6>
                        <button type="button" class="btn btn-sm btn-outline-danger remove-emergency-contact-btn">Remove</button>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ["emergency_contacts.$index.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="emergency_contacts[<?php echo e($index); ?>][name]" value="<?php echo e($contact['name'] ?? ''); ?>" required>
                            <?php $__errorArgs = ["emergency_contacts.$index.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Relationship <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ["emergency_contacts.$index.relationship"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="emergency_contacts[<?php echo e($index); ?>][relationship]" value="<?php echo e($contact['relationship'] ?? ''); ?>" required>
                            <?php $__errorArgs = ["emergency_contacts.$index.relationship"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Phone <span class="text-danger">*</span></label>
                            <input type="tel" class="form-control <?php $__errorArgs = ["emergency_contacts.$index.phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="emergency_contacts[<?php echo e($index); ?>][phone]" value="<?php echo e($contact['phone'] ?? ''); ?>" required>
                            <?php $__errorArgs = ["emergency_contacts.$index.phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Alternate Phone</label>
                            <input type="tel" class="form-control <?php $__errorArgs = ["emergency_contacts.$index.alternate_phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="emergency_contacts[<?php echo e($index); ?>][alternate_phone]" value="<?php echo e($contact['alternate_phone'] ?? ''); ?>">
                            <?php $__errorArgs = ["emergency_contacts.$index.alternate_phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <hr class="my-4">
    <h6 class="mb-3"><i class="fas fa-image me-2"></i>Employee Image</h6>
    <div class="row g-3 align-items-start">
        <div class="col-md-8">
            <input type="file"
                   class="form-control <?php $__errorArgs = ['employee_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   name="employee_image"
                   id="employee-image-input"
                   accept=".jpg,.jpeg,.png"
                   <?php echo e((!$isEdit || empty($employeeImagePath)) ? 'required' : ''); ?>>
            <small class="text-muted">Accepted formats: JPG, JPEG, PNG. Max size: 2MB.</small>
            <?php $__errorArgs = ['employee_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback d-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-4">
            <img src="<?php echo e($employeeImageUrl ?: ''); ?>" id="employee-image-preview" class="img-fluid rounded border <?php echo e($employeeImageUrl ? '' : 'd-none'); ?>" alt="Employee image preview">
        </div>
    </div>

    <hr class="my-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="mb-0"><i class="fas fa-file-upload me-2"></i>Documents</h6>
        <button type="button" class="btn btn-sm btn-outline-primary" id="add-document-row-btn">
            <i class="fas fa-plus me-1"></i>Add Document
        </button>
    </div>
    <?php $__errorArgs = ['documents'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger small mb-2"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div id="documents-container" data-next-index="<?php echo e(count($documents)); ?>">
        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $existingFilePath = $document['file_path'] ?? ($document['existing_file'] ?? null);
                $existingFileName = $document['file_name'] ?? ($document['existing_file_name'] ?? null);
            ?>
            <div class="card border mb-3 document-item" data-index="<?php echo e($index); ?>">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="mb-0">Document #<?php echo e($loop->iteration); ?></h6>
                        <button type="button" class="btn btn-sm btn-outline-danger remove-document-btn">Remove</button>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-5">
                            <label class="form-label">Document Type</label>
                            <select class="form-select <?php $__errorArgs = ["documents.$index.type"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="documents[<?php echo e($index); ?>][type]">
                                <option value="">Select Type</option>
                                <?php $__currentLoopData = $documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($documentType->id); ?>" <?php echo e((string) ($document['type'] ?? '') === (string) $documentType->id ? 'selected' : ''); ?>><?php echo e($documentType->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ["documents.$index.type"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label">File</label>
                            <input type="file" class="form-control <?php $__errorArgs = ["documents.$index.file"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="documents[<?php echo e($index); ?>][file]" accept=".jpg,.jpeg,.png,.pdf">
                            <?php $__errorArgs = ["documents.$index.file"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php if($existingFilePath): ?>
                                <div class="small mt-2">
                                    <a href="<?php echo e(Storage::url($existingFilePath)); ?>" target="_blank">Current: <?php echo e($existingFileName ?: basename($existingFilePath)); ?></a>
                                </div>
                            <?php endif; ?>
                            <input type="hidden" name="documents[<?php echo e($index); ?>][existing_file]" value="<?php echo e($existingFilePath); ?>">
                            <input type="hidden" name="documents[<?php echo e($index); ?>][existing_file_name]" value="<?php echo e($existingFileName); ?>">
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-4">
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save me-2"></i><?php echo e($submitLabel); ?>

        </button>
        <a href="<?php echo e($cancelUrl); ?>" class="btn btn-outline-secondary">Cancel</a>
    </div>
</form>

<?php $__env->startPush('scripts'); ?>
<script>
    (function () {
        const sameAsCheckbox = document.getElementById('same-as-present-address');
        const permanentWrapper = document.getElementById('permanent-address-wrapper');

        function getPresentAddressValue(key) {
            const input = document.querySelector('[name="present_address[' + key + ']"]');
            return input ? input.value : '';
        }

        function applySameAsPresent() {
            if (!sameAsCheckbox || !permanentWrapper) {
                return;
            }

            const permanentInputs = permanentWrapper.querySelectorAll('input, select, textarea');
            const isChecked = sameAsCheckbox.checked;

            permanentInputs.forEach(function (input) {
                const nameMatch = input.name.match(/permanent_address\[(.*)\]/);
                if (isChecked && nameMatch && nameMatch[1]) {
                    input.value = getPresentAddressValue(nameMatch[1]);
                }
                input.disabled = isChecked;
            });
        }

        if (sameAsCheckbox) {
            sameAsCheckbox.addEventListener('change', applySameAsPresent);
            document.querySelectorAll('[name^="present_address["]').forEach(function (input) {
                input.addEventListener('input', function () {
                    if (sameAsCheckbox.checked) {
                        applySameAsPresent();
                    }
                });
            });
            applySameAsPresent();
        }

        const employeeImageInput = document.getElementById('employee-image-input');
        const employeeImagePreview = document.getElementById('employee-image-preview');

        if (employeeImageInput && employeeImagePreview) {
            employeeImageInput.addEventListener('change', function (event) {
                const file = event.target.files && event.target.files[0];
                if (!file) {
                    return;
                }

                const reader = new FileReader();
                reader.onload = function (e) {
                    employeeImagePreview.src = e.target.result;
                    employeeImagePreview.classList.remove('d-none');
                };
                reader.readAsDataURL(file);
            });
        }

        const experienceContainer = document.getElementById('experience-container');
        const addExperienceBtn = document.getElementById('add-experience-btn');

        function experienceTemplate(index) {
            return `
                <div class="card border mb-3 experience-item" data-index="${index}">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="mb-0">Experience</h6>
                            <button type="button" class="btn btn-sm btn-outline-danger remove-experience-btn">Remove</button>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Company Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="experience[${index}][company_name]">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Job Title</label>
                                <input type="text" class="form-control" name="experience[${index}][job_title]">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Employment Type</label>
                                <select class="form-select" name="experience[${index}][employment_type]">
                                    <option value="">Select Type</option>
                                    <option value="full_time">Full Time</option>
                                    <option value="part_time">Part Time</option>
                                    <option value="contract">Contract</option>
                                    <option value="internship">Internship</option>
                                    <option value="freelance">Freelance</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Start Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" name="experience[${index}][start_date]">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">End Date</label>
                                <input type="date" class="form-control experience-end-date" name="experience[${index}][end_date]">
                                <div class="form-check mt-2">
                                    <input type="checkbox" class="form-check-input currently-working-checkbox" id="experience-currently-working-${index}" name="experience[${index}][currently_working]" value="1">
                                    <label class="form-check-label" for="experience-currently-working-${index}">Currently Working</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Last Salary</label>
                                <input type="number" step="0.01" class="form-control" name="experience[${index}][last_salary]">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Reason For Leaving</label>
                                <input type="text" class="form-control" name="experience[${index}][reason_for_leaving]">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Responsibilities</label>
                                <textarea class="form-control" rows="3" name="experience[${index}][responsibilities]"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }

        if (addExperienceBtn && experienceContainer) {
            addExperienceBtn.addEventListener('click', function () {
                const index = Number(experienceContainer.dataset.nextIndex || 0);
                experienceContainer.insertAdjacentHTML('beforeend', experienceTemplate(index));
                experienceContainer.dataset.nextIndex = String(index + 1);
            });

            experienceContainer.addEventListener('click', function (event) {
                if (event.target.classList.contains('remove-experience-btn')) {
                    event.target.closest('.experience-item').remove();
                }
            });

            experienceContainer.addEventListener('change', function (event) {
                if (!event.target.classList.contains('currently-working-checkbox')) {
                    return;
                }

                const card = event.target.closest('.experience-item');
                const endDateInput = card.querySelector('.experience-end-date');
                if (!endDateInput) {
                    return;
                }

                if (event.target.checked) {
                    endDateInput.value = '';
                    endDateInput.disabled = true;
                } else {
                    endDateInput.disabled = false;
                }
            });
        }

        const emergencyContainer = document.getElementById('emergency-contacts-container');
        const addEmergencyBtn = document.getElementById('add-emergency-contact-btn');

        function emergencyTemplate(index) {
            return `
                <div class="card border mb-3 emergency-contact-item" data-index="${index}">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="mb-0">Contact</h6>
                            <button type="button" class="btn btn-sm btn-outline-danger remove-emergency-contact-btn">Remove</button>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="emergency_contacts[${index}][name]" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Relationship <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="emergency_contacts[${index}][relationship]" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Phone <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" name="emergency_contacts[${index}][phone]" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Alternate Phone</label>
                                <input type="tel" class="form-control" name="emergency_contacts[${index}][alternate_phone]">
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }

        if (addEmergencyBtn && emergencyContainer) {
            addEmergencyBtn.addEventListener('click', function () {
                const index = Number(emergencyContainer.dataset.nextIndex || 0);
                emergencyContainer.insertAdjacentHTML('beforeend', emergencyTemplate(index));
                emergencyContainer.dataset.nextIndex = String(index + 1);
            });

            emergencyContainer.addEventListener('click', function (event) {
                if (!event.target.classList.contains('remove-emergency-contact-btn')) {
                    return;
                }

                if (emergencyContainer.querySelectorAll('.emergency-contact-item').length <= 2) {
                    alert('At least 2 emergency contacts are required.');
                    return;
                }

                event.target.closest('.emergency-contact-item').remove();
            });
        }

        const documentsContainer = document.getElementById('documents-container');
        const addDocumentBtn = document.getElementById('add-document-row-btn');
        const documentTypeOptions = <?php echo json_encode($documentTypes->map(function ($item) {
            return ['id' => $item->id, 'name' => $item->name];
        })->values(), 512) ?>;

        function documentOptionsHtml() {
            let options = '<option value="">Select Type</option>';
            documentTypeOptions.forEach(function (item) {
                options += `<option value="${item.id}">${item.name}</option>`;
            });
            return options;
        }

        function documentTemplate(index) {
            return `
                <div class="card border mb-3 document-item" data-index="${index}">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="mb-0">Document</h6>
                            <button type="button" class="btn btn-sm btn-outline-danger remove-document-btn">Remove</button>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-5">
                                <label class="form-label">Document Type</label>
                                <select class="form-select" name="documents[${index}][type]">
                                    ${documentOptionsHtml()}
                                </select>
                            </div>
                            <div class="col-md-5">
                                <label class="form-label">File</label>
                                <input type="file" class="form-control" name="documents[${index}][file]" accept=".jpg,.jpeg,.png,.pdf">
                                <input type="hidden" name="documents[${index}][existing_file]" value="">
                                <input type="hidden" name="documents[${index}][existing_file_name]" value="">
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }

        if (addDocumentBtn && documentsContainer) {
            addDocumentBtn.addEventListener('click', function () {
                const index = Number(documentsContainer.dataset.nextIndex || 0);
                documentsContainer.insertAdjacentHTML('beforeend', documentTemplate(index));
                documentsContainer.dataset.nextIndex = String(index + 1);
            });

            documentsContainer.addEventListener('click', function (event) {
                if (event.target.classList.contains('remove-document-btn')) {
                    event.target.closest('.document-item').remove();
                }
            });
        }
    })();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\Admin\Downloads\Extract\Mohawk\Mohawk\workspace\mani\homecare\resources\views/admin/employees/_form.blade.php ENDPATH**/ ?>