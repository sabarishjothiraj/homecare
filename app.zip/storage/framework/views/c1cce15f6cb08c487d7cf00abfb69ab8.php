<?php $__env->startSection('title', 'Patient Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1"><?php echo e($patient->name); ?></h2>
            <p class="text-muted mb-0">Patient Details</p>
        </div>
        <div>
            <a href="<?php echo e(route('admin.patients.edit', $patient)); ?>" class="btn btn-warning">
                <i class="fas fa-edit me-2"></i>Edit
            </a>
            <a href="<?php echo e(route('admin.patients.index')); ?>" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to List
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-3">
        <!-- Patient Information -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-user-injured me-2"></i>Patient Information</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="text-muted small">Full Name</label>
                            <p class="mb-0"><strong><?php echo e($patient->name); ?></strong></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Phone Number</label>
                            <p class="mb-0"><i class="fas fa-phone me-2 text-primary"></i><?php echo e($patient->phone); ?></p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Email Address</label>
                            <p class="mb-0">
                                <?php if($patient->email): ?>
                                    <i class="fas fa-envelope me-2 text-primary"></i><?php echo e($patient->email); ?>

                                <?php else: ?>
                                    <span class="text-muted">Not provided</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Caste</label>
                            <p class="mb-0">
                                <?php if($patient->caste): ?>
                                    <i class="fas fa-users me-2 text-primary"></i><?php echo e($patient->caste->name); ?>

                                <?php else: ?>
                                    <span class="text-muted">Not specified</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Subcaste</label>
                            <p class="mb-0">
                                <?php if($patient->subcaste): ?>
                                    <?php echo e($patient->subcaste); ?>

                                <?php else: ?>
                                    <span class="text-muted">Not specified</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-12">
                            <label class="text-muted small">Location</label>
                            <p class="mb-0"><?php echo e($patient->location); ?></p>
                        </div>
                        <div class="col-md-12">
                            <label class="text-muted small">Full Address</label>
                            <p class="mb-0"><?php echo e($patient->address); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Emergency Contact -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-phone-alt me-2"></i>Emergency Contact</h5>
                </div>
                <div class="card-body">
                    <?php if($patient->emergency_contact_name || $patient->emergency_contact_phone): ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="text-muted small">Contact Name</label>
                                <p class="mb-0"><?php echo e($patient->emergency_contact_name ?? 'Not provided'); ?></p>
                            </div>
                            <div class="col-md-6">
                                <label class="text-muted small">Contact Phone</label>
                                <p class="mb-0"><?php echo e($patient->emergency_contact_phone ?? 'Not provided'); ?></p>
                            </div>
                        </div>
                    <?php else: ?>
                        <p class="text-muted mb-0">No emergency contact information provided</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Medical Notes -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-notes-medical me-2"></i>Medical Notes</h5>
                </div>
                <div class="card-body">
                    <?php if($patient->medical_notes): ?>
                        <p class="mb-0"><?php echo e($patient->medical_notes); ?></p>
                    <?php else: ?>
                        <p class="text-muted mb-0">No medical notes recorded</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Contracts -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-file-contract me-2"></i>Contracts</h5>
                    <a href="<?php echo e(route('admin.contracts.create', ['patient_id' => $patient->id])); ?>" class="btn btn-sm btn-primary">
                        <i class="fas fa-plus me-1"></i>New Contract
                    </a>
                </div>
                <div class="card-body p-0">
                    <?php if($patient->contracts->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Service</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $patient->contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($contract->service->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($contract->start_date->format('M d, Y')); ?></td>
                                        <td><?php echo e($contract->end_date->format('M d, Y')); ?></td>
                                        <td>₹<?php echo e(number_format($contract->total_amount, 0)); ?></td>
                                        <td>
                                            <?php if($contract->status === 'active'): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php elseif($contract->status === 'pending'): ?>
                                                <span class="badge bg-warning">Pending</span>
                                            <?php elseif($contract->status === 'completed'): ?>
                                                <span class="badge bg-info">Completed</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary"><?php echo e(ucfirst($contract->status)); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('admin.contracts.show', $contract)); ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-file-contract fa-3x text-muted mb-3 opacity-25"></i>
                            <p class="text-muted">No contracts yet</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-md-4">
            <!-- Status Card -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Status</h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="text-muted small">Patient Status</label>
                        <p class="mb-0">
                            <?php if($patient->is_active): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Inactive</span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Downloads\Extract\Mohawk\Mohawk\workspace\mani\homecare\resources\views/admin/patients/show.blade.php ENDPATH**/ ?>