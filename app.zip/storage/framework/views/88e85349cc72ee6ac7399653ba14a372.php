<?php $__env->startSection('title', 'Employee Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1"><?php echo e($employee->getField('name', 'Employee #' . $employee->id)); ?></h2>
            <p class="text-muted mb-0">Employee Details</p>
        </div>
        <div>
            <a href="<?php echo e(route('admin.employees.edit', $employee)); ?>" class="btn btn-warning">
                <i class="fas fa-edit me-2"></i>Edit
            </a>
            <?php if($employee->status === 'pending'): ?>
                <form action="<?php echo e(route('admin.employees.activate', $employee)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check me-2"></i>Activate
                    </button>
                </form>
            <?php elseif($employee->status === 'active'): ?>
                <form action="<?php echo e(route('admin.employees.deactivate', $employee)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-ban me-2"></i>Deactivate
                    </button>
                </form>
            <?php endif; ?>
            <a href="<?php echo e(route('admin.employees.index')); ?>" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to List
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-3">
        <!-- Employee Information -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-user-nurse me-2"></i>Employee Information</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <?php $__currentLoopData = $fields->where('is_document', false); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <label class="text-muted small"><?php echo e($field->label); ?></label>
                                <p class="mb-0">
                                    <?php if($employee->getField($field->name)): ?>
                                        <strong><?php echo e($employee->getField($field->name)); ?></strong>
                                    <?php else: ?>
                                        <span class="text-muted">Not provided</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- Caste Information -->
                        <div class="col-md-6">
                            <label class="text-muted small">Caste</label>
                            <p class="mb-0">
                                <?php if($employee->caste): ?>
                                    <strong><?php echo e($employee->caste->name); ?></strong>
                                <?php else: ?>
                                    <span class="text-muted">Not specified</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Subcaste</label>
                            <p class="mb-0">
                                <?php if($employee->subcaste): ?>
                                    <strong><?php echo e($employee->subcaste); ?></strong>
                                <?php else: ?>
                                    <span class="text-muted">Not specified</span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Documents -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-file-alt me-2"></i>Documents</h5>
                </div>
                <div class="card-body">
                    <?php if($employee->documents->count() > 0): ?>
                        <div class="row g-3">
                            <?php $__currentLoopData = $employee->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6">
                                    <div class="border rounded p-3">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div>
                                                <h6 class="mb-1"><?php echo e($document->field->label ?? 'Document'); ?></h6>
                                                <p class="small text-muted mb-2"><?php echo e($document->file_name); ?></p>
                                                <small class="text-muted">
                                                    <?php echo e(number_format($document->file_size / 1024, 2)); ?> KB
                                                </small>
                                            </div>
                                            <a href="<?php echo e(Storage::url($document->file_path)); ?>" target="_blank" class="btn btn-sm btn-primary">
                                                <i class="fas fa-download"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted mb-0">No documents uploaded</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Assignments -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-tasks me-2"></i>Assignments</h5>
                </div>
                <div class="card-body p-0">
                    <?php if($employee->assignments->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Contract</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $employee->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($assignment->contract->patient->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($assignment->start_date->format('M d, Y')); ?></td>
                                        <td><?php echo e($assignment->end_date ? $assignment->end_date->format('M d, Y') : 'Ongoing'); ?></td>
                                        <td>
                                            <?php if($assignment->is_active): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('admin.contracts.show', $assignment->contract_id)); ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-tasks fa-3x text-muted mb-3 opacity-25"></i>
                            <p class="text-muted">No assignments yet</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Payouts -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="fas fa-money-bill-wave me-2"></i>Payouts</h5>
                </div>
                <div class="card-body p-0">
                    <?php if($employee->payouts->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $employee->payouts->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($payout->created_at->format('M d, Y')); ?></td>
                                        <td>₹<?php echo e(number_format($payout->amount, 0)); ?></td>
                                        <td>
                                            <span class="badge bg-success">Paid</span>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-money-bill-wave fa-3x text-muted mb-3 opacity-25"></i>
                            <p class="text-muted">No payouts yet</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-md-4">
            <!-- Status Card -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Status</h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="text-muted small">Employee Status</label>
                        <p class="mb-0">
                            <?php if($employee->status === 'active'): ?>
                                <span class="badge bg-success">Active</span>
                            <?php elseif($employee->status === 'pending'): ?>
                                <span class="badge bg-warning">Pending</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Inactive</span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="mb-3">
                        <label class="text-muted small">Joined</label>
                        <p class="mb-0"><?php echo e($employee->created_at->format('M d, Y')); ?></p>
                    </div>
                    <?php if($employee->activated_at): ?>
                        <div>
                            <label class="text-muted small">Activated</label>
                            <p class="mb-0"><?php echo e($employee->activated_at->format('M d, Y')); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Downloads\Extract\Mohawk\Mohawk\workspace\mani\homecare\resources\views/admin/employees/show.blade.php ENDPATH**/ ?>