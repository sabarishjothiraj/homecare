<?php $__env->startSection('title', 'Patients'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Patients</h2>
            <p class="text-muted mb-0">Manage patient records</p>
        </div>
        <a href="<?php echo e(route('admin.patients.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Add New Patient
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Filters -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.patients.index')); ?>" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Search</label>
                    <input type="text" name="search" class="form-control" placeholder="Name, email, or phone..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="">All Status</option>
                        <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Community</label>
                    <select name="community" class="form-select">
                        <option value="">All Communities</option>
                        <?php $__currentLoopData = $communities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $community): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($community); ?>" <?php echo e(request('community') === $community ? 'selected' : ''); ?>>
                                <?php echo e($community); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i>Filter
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Patients Table -->
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <?php if($patients->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Community</th>
                                <th>Location</th>
                                <th>Contracts</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary bg-opacity-10 rounded-circle p-2 me-2">
                                            <i class="fas fa-user-injured text-primary"></i>
                                        </div>
                                        <div>
                                            <strong><?php echo e($patient->name); ?></strong>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="small">
                                        <?php if($patient->email): ?>
                                            <div><i class="fas fa-envelope me-1 text-muted"></i><?php echo e($patient->email); ?></div>
                                        <?php endif; ?>
                                        <div><i class="fas fa-phone me-1 text-muted"></i><?php echo e($patient->phone); ?></div>
                                    </div>
                                </td>
                                <td><?php echo e($patient->community); ?></td>
                                <td><?php echo e(Str::limit($patient->location, 30)); ?></td>
                                <td>
                                    <span class="badge bg-info"><?php echo e($patient->contracts_count); ?> Total</span>
                                    <?php if($patient->active_contracts_count > 0): ?>
                                        <span class="badge bg-success"><?php echo e($patient->active_contracts_count); ?> Active</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($patient->is_active): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('admin.patients.show', $patient)); ?>" class="btn btn-outline-primary" title="View">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.patients.edit', $patient)); ?>" class="btn btn-outline-warning" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-outline-danger" title="Delete" 
                                                onclick="confirmDelete(<?php echo e($patient->id); ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                    <form id="delete-form-<?php echo e($patient->id); ?>" 
                                          action="<?php echo e(route('admin.patients.destroy', $patient)); ?>" 
                                          method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="card-footer bg-white">
                    <?php echo e($patients->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-user-injured fa-4x text-muted mb-3 opacity-25"></i>
                    <h5 class="text-muted">No patients found</h5>
                    <p class="text-muted">Start by adding your first patient</p>
                    <a href="<?php echo e(route('admin.patients.create')); ?>" class="btn btn-primary mt-3">
                        <i class="fas fa-plus me-2"></i>Add New Patient
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function confirmDelete(id) {
    if (confirm('Are you sure you want to delete this patient? This action cannot be undone.')) {
        document.getElementById('delete-form-' + id).submit();
    }
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Sabarish\Mohawk\workspace\mani\homenursing\resources\views/admin/patients/index.blade.php ENDPATH**/ ?>