<?php

namespace App\Services;

use App\Models\OtpVerification;
use App\Models\User;

class OtpService
{
    /**
     * Temporary static OTP for non-super-admin login flow.
     */
    public function generate(User $user): string
    {
        return (string) config('otp.static_otp', '123456');
    }

    /**
     * Verify OTP using isolated service logic so SMS/real OTP can replace this later.
     */
    public function verify(User $user, string $otp, ?OtpVerification $verification = null): bool
    {
        return hash_equals($this->generate($user), trim($otp));
    }

    public function expiryMinutes(): int
    {
        return (int) config('otp.expiry_minutes', 5);
    }
}
