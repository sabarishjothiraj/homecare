<?php

namespace App\Services;

use App\Models\Payment;
use App\Models\Contract;
use App\Models\Employee;
use Razorpay\Api\Api;
use Exception;

class PaymentService
{
    protected $razorpay;

    public function __construct()
    {
        $this->razorpay = new Api(
            config('services.razorpay.key'),
            config('services.razorpay.secret')
        );
    }

    /**
     * Create Razorpay order for contract payment
     */
    public function createContractOrder(Contract $contract): array
    {
        try {
            $order = $this->razorpay->order->create([
                'amount' => $contract->amount * 100, // Amount in paise
                'currency' => 'INR',
                'receipt' => 'contract_' . $contract->id,
                'notes' => [
                    'contract_id' => $contract->id,
                    'patient_id' => $contract->patient_id,
                    'type' => 'contract_payment'
                ]
            ]);

            // Create payment record
            $payment = Payment::create([
                'payment_type' => 'contract',
                'contract_id' => $contract->id,
                'razorpay_order_id' => $order->id,
                'amount' => $contract->amount,
                'status' => 'pending',
                'method' => 'razorpay',
            ]);

            return [
                'success' => true,
                'order_id' => $order->id,
                'amount' => $contract->amount,
                'payment_id' => $payment->id,
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * Create Razorpay order for employee activation
     */
    public function createEmployeeActivationOrder(Employee $employee): array
    {
        try {
            $amount = config('services.razorpay.employee_payment_amount', 1000);

            $order = $this->razorpay->order->create([
                'amount' => $amount * 100, // Amount in paise
                'currency' => 'INR',
                'receipt' => 'employee_' . $employee->id,
                'notes' => [
                    'employee_id' => $employee->id,
                    'type' => 'employee_activation'
                ]
            ]);

            // Create payment record
            $payment = Payment::create([
                'payment_type' => 'employee_activation',
                'employee_id' => $employee->id,
                'razorpay_order_id' => $order->id,
                'amount' => $amount,
                'status' => 'pending',
                'method' => 'razorpay',
            ]);

            return [
                'success' => true,
                'order_id' => $order->id,
                'amount' => $amount,
                'payment_id' => $payment->id,
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * Verify Razorpay payment signature
     */
    public function verifyPayment(string $orderId, string $paymentId, string $signature): bool
    {
        try {
            $attributes = [
                'razorpay_order_id' => $orderId,
                'razorpay_payment_id' => $paymentId,
                'razorpay_signature' => $signature,
            ];

            $this->razorpay->utility->verifyPaymentSignature($attributes);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Process successful payment
     */
    public function processSuccessfulPayment(string $orderId, string $paymentId, string $signature): bool
    {
        $payment = Payment::where('razorpay_order_id', $orderId)->first();

        if (!$payment) {
            return false;
        }

        if (!$this->verifyPayment($orderId, $paymentId, $signature)) {
            $payment->update(['status' => 'failed']);
            return false;
        }

        $payment->update([
            'razorpay_payment_id' => $paymentId,
            'razorpay_signature' => $signature,
            'status' => 'completed',
            'paid_at' => now(),
        ]);

        // Handle post-payment actions
        if ($payment->payment_type === 'employee_activation' && $payment->employee) {
            $this->activateEmployee($payment->employee);
        }

        return true;
    }

    /**
     * Activate employee after payment
     */
    protected function activateEmployee(Employee $employee): void
    {
        $validityMonths = config('services.razorpay.employee_payment_validity_months', 12);

        $employee->update([
            'status' => 'active',
            'activated_at' => now(),
            'payment_valid_until' => now()->addMonths($validityMonths),
        ]);
    }
}

