<?php

namespace App\Services;

use App\Models\Contract;
use App\Models\Patient;
use App\Models\Setting;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;

class ContractService
{
    /**
     * Create a new contract
     */
    public function createContract(array $data): Contract
    {
        // Calculate end date based on duration type
        $endDate = $this->calculateEndDate(
            $data['start_date'],
            $data['duration_type'],
            $data['duration_value'] ?? null,
            $data['custom_end_date'] ?? null
        );

        $contract = Contract::create([
            'patient_id' => $data['patient_id'],
            'service_id' => $data['service_id'],
            'duration_type' => $data['duration_type'],
            'duration_value' => $data['duration_value'] ?? null,
            'start_date' => $data['start_date'],
            'end_date' => $endDate,
            'amount' => $data['amount'],
            'payment_method' => $data['payment_method'],
            'terms' => $data['terms'] ?? $this->getDefaultTerms(),
            'status' => 'not_assigned',
        ]);

        // Generate PDF
        $this->generateContractPDF($contract);

        return $contract;
    }

    /**
     * Calculate end date based on duration type
     */
    protected function calculateEndDate(string $startDate, string $durationType, ?int $durationValue = null, ?string $customEndDate = null): ?string
    {
        $start = Carbon::parse($startDate);
        $value = $durationValue ?? 1;

        return match($durationType) {
            'daily' => $start->addDays($value)->format('Y-m-d'),
            'weekly' => $start->addWeeks($value)->format('Y-m-d'),
            'monthly' => $start->addMonths($value)->format('Y-m-d'),
            'yearly' => $start->addYears($value)->format('Y-m-d'),
            'custom' => $customEndDate,
            default => null,
        };
    }

    /**
     * Generate contract PDF
     */
    public function generateContractPDF(Contract $contract): string
    {
        $contract->load(['patient', 'service']);

        $data = [
            'contract' => $contract,
            'company_name' => Setting::get('company_name', 'Home Nursing Care'),
            'company_address' => Setting::get('company_address', ''),
            'company_phone' => Setting::get('company_phone', ''),
            'company_email' => Setting::get('company_email', ''),
            'company_logo' => Setting::get('company_logo', ''),
        ];

        $pdf = Pdf::loadView('pdf.contract', $data);
        
        $filename = 'contract_' . $contract->contract_number . '.pdf';
        $path = 'contracts/' . $filename;
        
        // Save PDF
        $pdf->save(storage_path('app/public/' . $path));

        // Update contract with PDF path
        $contract->update(['pdf_path' => $path]);

        return $path;
    }

    /**
     * Close a contract
     */
    public function closeContract(Contract $contract, string $reason): bool
    {
        return $contract->update([
            'status' => 'closed',
            'closure_reason' => $reason,
            'closed_at' => now(),
        ]);
    }

    /**
     * Update contract statuses based on dates
     */
    public function updateContractStatuses(): void
    {
        $contracts = Contract::whereNotIn('status', ['closed'])->get();

        foreach ($contracts as $contract) {
            $contract->updateStatus();
        }
    }

    /**
     * Get contracts expiring soon
     */
    public function getExpiringContracts(): \Illuminate\Database\Eloquent\Collection
    {
        $alertDays = Setting::get('contract_alert_days', 7);
        $alertDate = Carbon::now()->addDays($alertDays);

        return Contract::where('status', '!=', 'closed')
            ->whereNotNull('end_date')
            ->whereBetween('end_date', [Carbon::now(), $alertDate])
            ->with(['patient', 'service'])
            ->get();
    }

    /**
     * Get default contract terms
     */
    protected function getDefaultTerms(): string
    {
        return "1. The service provider agrees to provide nursing care as per the agreed schedule.\n" .
               "2. Payment must be made as per the agreed payment method and schedule.\n" .
               "3. Either party may terminate this contract with 7 days written notice.\n" .
               "4. The service provider maintains professional liability insurance.\n" .
               "5. All personal and medical information will be kept confidential.\n" .
               "6. The client agrees to provide a safe working environment for the nurse.\n" .
               "7. Any changes to the service schedule must be communicated 24 hours in advance.\n" .
               "8. This contract is governed by the laws of the applicable jurisdiction.";
    }

    /**
     * Generate contract statistics
     */
    public function getContractStatistics(): array
    {
        return [
            'total' => Contract::count(),
            'active' => Contract::where('status', 'active')->count(),
            'not_assigned' => Contract::where('status', 'not_assigned')->count(),
            'closing_soon' => Contract::where('status', 'closing_soon')->count(),
            'expired' => Contract::where('status', 'expired')->count(),
            'closed' => Contract::where('status', 'closed')->count(),
        ];
    }
}

