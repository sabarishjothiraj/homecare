<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Carbon\Carbon;

class Contract extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'contract_number',
        'patient_id',
        'service_id',
        'created_by',
        'duration_type',
        'duration_value',
        'start_date',
        'end_date',
        'amount',
        'payment_method',
        'status',
        'terms',
        'pdf_path',
        'closure_reason',
        'closed_at',
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
        'amount' => 'decimal:2',
        'closed_at' => 'datetime',
    ];

    /**
     * Boot method
     */
    protected static function boot()
    {
        parent::boot();
        
        static::creating(function ($contract) {
            if (!$contract->contract_number) {
                $contract->contract_number = 'CNT-' . strtoupper(uniqid());
            }
        });
    }

    /**
     * Get the patient
     */
    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    /**
     * Get the service
     */
    public function service()
    {
        return $this->belongsTo(Service::class);
    }

    /**
     * Get assignments
     */
    public function assignments()
    {
        return $this->hasMany(Assignment::class);
    }

    /**
     * Get service line items
     */
    public function items()
    {
        return $this->hasMany(ContractItem::class);
    }

    /**
     * Get active assignment
     */
    public function activeAssignment()
    {
        return $this->hasOne(Assignment::class)->where('is_active', true)->latest();
    }

    /**
     * Get active assignments
     */
    public function activeAssignments()
    {
        return $this->hasMany(Assignment::class)->where('is_active', true)->latest();
    }

    /**
     * Get payments
     */
    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    /**
     * Scope for active contracts
     */
    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    /**
     * Scope for closing soon
     */
    public function scopeClosingSoon($query)
    {
        return $query->where('status', 'closing_soon');
    }

    /**
     * Scope for not assigned
     */
    public function scopeNotAssigned($query)
    {
        return $query->where('status', 'not_assigned');
    }

    /**
     * Check if contract is expiring soon
     */
    public function isExpiringSoon(): bool
    {
        if (!$this->end_date) {
            return false;
        }
        
        $alertDays = Setting::get('contract_alert_days', 7);
        $daysUntilExpiry = Carbon::now()->diffInDays($this->end_date, false);
        
        return $daysUntilExpiry >= 0 && $daysUntilExpiry <= $alertDays;
    }

    /**
     * Check if contract is expired
     */
    public function isExpired(): bool
    {
        if (!$this->end_date) {
            return false;
        }
        
        return Carbon::now()->isAfter($this->end_date);
    }

    /**
     * Update contract status based on dates and assignments
     */
    public function updateStatus(): void
    {
        if ($this->status === 'closed') {
            return;
        }

        if ($this->isExpired()) {
            $this->status = 'expired';
        } elseif ($this->isExpiringSoon()) {
            $this->status = 'closing_soon';
        } elseif (!$this->assignments()->active()->exists()) {
            $this->status = 'not_assigned';
        } else {
            $this->status = 'active';
        }

        $this->save();
    }
}

