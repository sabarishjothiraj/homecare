<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Contract;
use App\Models\Patient;
use App\Models\Service;
use App\Services\ContractService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ContractController extends Controller
{
    protected $contractService;

    public function __construct(ContractService $contractService)
    {
        $this->contractService = $contractService;
    }

    /**
     * Display contract listing
     */
    public function index(Request $request)
    {
        $query = Contract::with(['patient', 'service', 'activeAssignment']);

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filter by patient
        if ($request->filled('patient_id')) {
            $query->where('patient_id', $request->patient_id);
        }

        // Search
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('contract_number', 'like', "%{$search}%")
                  ->orWhereHas('patient', function($pq) use ($search) {
                      $pq->where('name', 'like', "%{$search}%");
                  });
            });
        }

        $contracts = $query->latest()->paginate(20);
        $patients = Patient::active()->orderBy('name')->get();

        return view('admin.contracts.index', compact('contracts', 'patients'));
    }

    /**
     * Show create form
     */
    public function create()
    {
        $patients = Patient::active()->orderBy('name')->get();
        $services = Service::active()->ordered()->get();

        return view('admin.contracts.create', compact('patients', 'services'));
    }

    /**
     * Store new contract
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'service_id' => 'required|exists:services,id',
            'duration_type' => 'required|in:daily,weekly,monthly,yearly,custom',
            'duration_value' => 'required_unless:duration_type,custom|nullable|integer|min:1',
            'start_date' => 'required|date',
            'amount' => 'required|numeric|min:0',
            'payment_method' => 'required|in:cash,razorpay',
            'terms' => 'nullable|string',
        ]);

        $contract = $this->contractService->createContract($validated);

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Contract created successfully. PDF has been generated.',
                'redirect' => route('admin.contracts.show', $contract)
            ]);
        }

        return redirect()->route('admin.contracts.show', $contract)
            ->with('success', 'Contract created successfully. PDF has been generated.');
    }

    /**
     * Show contract details
     */
    public function show(Contract $contract)
    {
        $contract->load(['patient', 'service', 'assignments.employee', 'payments']);

        return view('admin.contracts.show', compact('contract'));
    }

    /**
     * Show edit form
     */
    public function edit(Contract $contract)
    {
        if ($contract->status === 'closed') {
            if (request()->wantsJson() || request()->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Cannot edit a closed contract.'
                ], 422);
            }
            return redirect()->back()
                ->with('error', 'Cannot edit a closed contract.');
        }

        $patients = Patient::active()->orderBy('name')->get();
        $services = Service::active()->ordered()->get();

        return view('admin.contracts.edit', compact('contract', 'patients', 'services'));
    }

    /**
     * Update contract
     */
    public function update(Request $request, Contract $contract)
    {
        if ($contract->status === 'closed') {
            if ($request->wantsJson() || $request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Cannot update a closed contract.'
                ], 422);
            }
            return redirect()->back()
                ->with('error', 'Cannot update a closed contract.');
        }

        $validated = $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'service_id' => 'required|exists:services,id',
            'duration_type' => 'required|in:daily,weekly,monthly,yearly,custom',
            'duration_value' => 'required_unless:duration_type,custom|nullable|integer|min:1',
            'start_date' => 'required|date',
            'amount' => 'required|numeric|min:0',
            'payment_method' => 'required|in:cash,razorpay',
            'terms' => 'nullable|string',
        ]);

        // Calculate end date
        $startDate = \Carbon\Carbon::parse($validated['start_date']);
        $endDate = null;

        if ($validated['duration_type'] === 'daily') {
            $endDate = $startDate->copy()->addDays($validated['duration_value']);
        } elseif ($validated['duration_type'] === 'weekly') {
            $endDate = $startDate->copy()->addWeeks($validated['duration_value']);
        } elseif ($validated['duration_type'] === 'monthly') {
            $endDate = $startDate->copy()->addMonths($validated['duration_value']);
        } elseif ($validated['duration_type'] === 'yearly') {
            $endDate = $startDate->copy()->addYears($validated['duration_value']);
        }

        $contract->update([
            'patient_id' => $validated['patient_id'],
            'service_id' => $validated['service_id'],
            'duration_type' => $validated['duration_type'],
            'duration_value' => $validated['duration_value'],
            'start_date' => $startDate,
            'end_date' => $endDate,
            'amount' => $validated['amount'],
            'payment_method' => $validated['payment_method'],
            'terms' => $validated['terms'],
        ]);

        // Update status
        $contract->updateStatus();

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Contract updated successfully.',
                'redirect' => route('admin.contracts.show', $contract)
            ]);
        }

        return redirect()->route('admin.contracts.show', $contract)
            ->with('success', 'Contract updated successfully.');
    }

    /**
     * Close contract
     */
    public function close(Request $request, Contract $contract)
    {
        $validated = $request->validate([
            'closure_reason' => 'required|string|max:1000',
        ]);

        $this->contractService->closeContract($contract, $validated['closure_reason']);

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Contract closed successfully.',
                'redirect' => route('admin.contracts.show', $contract)
            ]);
        }

        return redirect()->route('admin.contracts.show', $contract)
            ->with('success', 'Contract closed successfully.');
    }

    /**
     * Download contract PDF
     */
    public function download(Contract $contract)
    {
        if (!$contract->pdf_path || !Storage::disk('public')->exists($contract->pdf_path)) {
            return redirect()->back()
                ->with('error', 'Contract PDF not found. Please regenerate it.');
        }

        return Storage::disk('public')->download($contract->pdf_path, "Contract-{$contract->contract_number}.pdf");
    }

    /**
     * Regenerate contract PDF
     */
    public function regeneratePdf(Contract $contract)
    {
        $this->contractService->generateContractPDF($contract);

        if (request()->wantsJson() || request()->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Contract PDF regenerated successfully.',
                'reload' => true
            ]);
        }

        return redirect()->back()
            ->with('success', 'Contract PDF regenerated successfully.');
    }
}

