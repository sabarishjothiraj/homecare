<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Services\PaymentService;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    protected $paymentService;

    public function __construct(PaymentService $paymentService)
    {
        $this->paymentService = $paymentService;
    }

    /**
     * Display payment listing
     */
    public function index(Request $request)
    {
        $query = Payment::with(['contract.patient']);

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filter by payment type
        if ($request->filled('payment_type')) {
            $query->where('payment_type', $request->payment_type);
        }

        // Filter by method
        if ($request->filled('method')) {
            $query->where('method', $request->method);
        }

        // Date range filter
        if ($request->filled('start_date')) {
            $query->whereDate('paid_at', '>=', $request->start_date);
        }

        if ($request->filled('end_date')) {
            $query->whereDate('paid_at', '<=', $request->end_date);
        }

        $payments = $query->latest('paid_at')->paginate(20);

        // Calculate totals
        $totalAmount = Payment::completed()->sum('amount');
        $pendingAmount = Payment::pending()->sum('amount');

        return view('admin.payments.index', compact('payments', 'totalAmount', 'pendingAmount'));
    }

    /**
     * Show payment details
     */
    public function show(Payment $payment)
    {
        $payment->load(['contract.patient', 'contract.service']);

        return view('admin.payments.show', compact('payment'));
    }

    /**
     * Handle Razorpay webhook
     */
    public function webhook(Request $request)
    {
        try {
            $webhookSecret = config('services.razorpay.webhook_secret');
            $webhookSignature = $request->header('X-Razorpay-Signature');
            $webhookBody = $request->getContent();

            // Verify webhook signature
            $expectedSignature = hash_hmac('sha256', $webhookBody, $webhookSecret);

            if ($webhookSignature !== $expectedSignature) {
                return response()->json(['error' => 'Invalid signature'], 400);
            }

            $payload = $request->all();

            // Handle payment success
            if ($payload['event'] === 'payment.captured') {
                $razorpayPaymentId = $payload['payload']['payment']['entity']['id'];
                $razorpayOrderId = $payload['payload']['payment']['entity']['order_id'];

                $this->paymentService->processSuccessfulPayment($razorpayOrderId, $razorpayPaymentId);
            }

            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            \Log::error('Razorpay webhook error: ' . $e->getMessage());
            return response()->json(['error' => 'Webhook processing failed'], 500);
        }
    }

    /**
     * Handle payment callback
     */
    public function callback(Request $request)
    {
        try {
            $razorpayPaymentId = $request->input('razorpay_payment_id');
            $razorpayOrderId = $request->input('razorpay_order_id');
            $razorpaySignature = $request->input('razorpay_signature');

            // Verify payment
            $isValid = $this->paymentService->verifyPayment(
                $razorpayOrderId,
                $razorpayPaymentId,
                $razorpaySignature
            );

            if ($isValid) {
                $this->paymentService->processSuccessfulPayment($razorpayOrderId, $razorpayPaymentId);

                return redirect()->route('admin.payments.index')
                    ->with('success', 'Payment completed successfully!');
            } else {
                return redirect()->route('admin.payments.index')
                    ->with('error', 'Payment verification failed!');
            }

        } catch (\Exception $e) {
            \Log::error('Payment callback error: ' . $e->getMessage());
            
            return redirect()->route('admin.payments.index')
                ->with('error', 'Payment processing failed: ' . $e->getMessage());
        }
    }
}

