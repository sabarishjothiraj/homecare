<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Caste;
use App\Models\Employee;
use App\Models\EmployeeField;
use App\Models\EmployeeDocument;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class EmployeeController extends Controller
{
    /**
     * Display employee listing
     */
    public function index(Request $request)
    {
        $query = Employee::with('documents');

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Search
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('field_data', 'like', "%{$search}%");
            });
        }

        $employees = $query->latest()->paginate(20);

        return view('admin.employees.index', compact('employees'));
    }

    /**
     * Show create form
     */
    public function create()
    {
        $fields = EmployeeField::active()->ordered()->get();
        $castes = Caste::active()->ordered()->get();
        return view('admin.employees.create', compact('fields', 'castes'));
    }

    /**
     * Store new employee
     */
    public function store(Request $request)
    {
        $fields = EmployeeField::active()->get();
        
        // Build validation rules dynamically
        $rules = [];
        foreach ($fields as $field) {
            if ($field->is_document) {
                continue; // Documents handled separately
            }

            $fieldRules = [];
            if ($field->is_required) {
                $fieldRules[] = 'required';
            } else {
                $fieldRules[] = 'nullable';
            }

            switch ($field->type) {
                case 'email':
                    $fieldRules[] = 'email';
                    break;
                case 'number':
                    $fieldRules[] = 'numeric';
                    break;
                case 'date':
                    $fieldRules[] = 'date';
                    break;
            }

            $rules[$field->name] = implode('|', $fieldRules);
        }

        // Add caste validation rules
        $rules['caste_id'] = 'nullable|exists:castes,id';
        $rules['subcaste'] = 'nullable|string|max:100';

        $validated = $request->validate($rules);

        // Extract caste fields
        $casteId = $validated['caste_id'] ?? null;
        $subcaste = $validated['subcaste'] ?? null;
        unset($validated['caste_id'], $validated['subcaste']);

        // Create employee
        $employee = Employee::create([
            'field_data' => $validated,
            'caste_id' => $casteId,
            'subcaste' => $subcaste,
            'status' => 'pending',
        ]);

        // Handle document uploads
        foreach ($fields as $field) {
            if ($field->is_document && $request->hasFile($field->name)) {
                $file = $request->file($field->name);
                $path = $file->store('employee_documents', 'public');

                EmployeeDocument::create([
                    'employee_id' => $employee->id,
                    'field_id' => $field->id,
                    'file_path' => $path,
                    'file_name' => $file->getClientOriginalName(),
                    'file_type' => $file->getClientMimeType(),
                    'file_size' => $file->getSize(),
                ]);
            }
        }

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Employee created successfully.',
                'redirect' => route('admin.employees.index')
            ]);
        }

        return redirect()->route('admin.employees.index')
            ->with('success', 'Employee created successfully.');
    }

    /**
     * Show employee details
     */
    public function show(Employee $employee)
    {
        $employee->load(['documents.field', 'assignments.contract', 'payouts']);
        $fields = EmployeeField::active()->ordered()->get();
        
        return view('admin.employees.show', compact('employee', 'fields'));
    }

    /**
     * Show edit form
     */
    public function edit(Employee $employee)
    {
        $fields = EmployeeField::active()->ordered()->get();
        $castes = Caste::active()->ordered()->get();
        return view('admin.employees.edit', compact('employee', 'fields', 'castes'));
    }

    /**
     * Update employee
     */
    public function update(Request $request, Employee $employee)
    {
        $fields = EmployeeField::active()->get();
        
        // Build validation rules
        $rules = [];
        foreach ($fields as $field) {
            if ($field->is_document) continue;

            $fieldRules = $field->is_required ? ['required'] : ['nullable'];
            
            switch ($field->type) {
                case 'email': $fieldRules[] = 'email'; break;
                case 'number': $fieldRules[] = 'numeric'; break;
                case 'date': $fieldRules[] = 'date'; break;
            }

            $rules[$field->name] = implode('|', $fieldRules);
        }

        // Add caste validation rules
        $rules['caste_id'] = 'nullable|exists:castes,id';
        $rules['subcaste'] = 'nullable|string|max:100';

        $validated = $request->validate($rules);

        // Extract caste fields
        $casteId = $validated['caste_id'] ?? null;
        $subcaste = $validated['subcaste'] ?? null;
        unset($validated['caste_id'], $validated['subcaste']);

        // Update employee
        $employee->update([
            'field_data' => $validated,
            'caste_id' => $casteId,
            'subcaste' => $subcaste,
        ]);

        // Handle new document uploads
        foreach ($fields as $field) {
            if ($field->is_document && $request->hasFile($field->name)) {
                // Delete old document if exists
                $oldDoc = $employee->documents()->where('field_id', $field->id)->first();
                if ($oldDoc) {
                    Storage::disk('public')->delete($oldDoc->file_path);
                    $oldDoc->delete();
                }

                // Upload new document
                $file = $request->file($field->name);
                $path = $file->store('employee_documents', 'public');

                EmployeeDocument::create([
                    'employee_id' => $employee->id,
                    'field_id' => $field->id,
                    'file_path' => $path,
                    'file_name' => $file->getClientOriginalName(),
                    'file_type' => $file->getClientMimeType(),
                    'file_size' => $file->getSize(),
                ]);
            }
        }

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Employee updated successfully.',
                'redirect' => route('admin.employees.show', $employee)
            ]);
        }

        return redirect()->route('admin.employees.show', $employee)
            ->with('success', 'Employee updated successfully.');
    }

    /**
     * Activate employee
     */
    public function activate(Employee $employee)
    {
        $employee->update(['status' => 'active']);

        if (request()->wantsJson() || request()->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Employee activated successfully.',
                'reload' => true
            ]);
        }

        return redirect()->back()
            ->with('success', 'Employee activated successfully.');
    }

    /**
     * Deactivate employee
     */
    public function deactivate(Employee $employee)
    {
        $employee->update(['status' => 'inactive']);

        if (request()->wantsJson() || request()->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Employee deactivated successfully.',
                'reload' => true
            ]);
        }

        return redirect()->back()
            ->with('success', 'Employee deactivated successfully.');
    }
}

