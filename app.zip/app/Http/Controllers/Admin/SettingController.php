<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;

class SettingController extends Controller
{
    /**
     * Display settings page
     */
    public function index()
    {
        $settings = Setting::all()->groupBy('group');

        return view('admin.settings.index', compact('settings'));
    }

    /**
     * Update settings
     */
    public function update(Request $request)
    {
        $validated = $request->validate([
            'company_name' => 'required|string|max:255',
            'company_email' => 'required|email|max:255',
            'company_phone' => 'required|string|max:20',
            'company_address' => 'required|string|max:500',
            'company_description' => 'nullable|string',
            'company_logo' => 'nullable|image|max:2048',
            'website_title' => 'nullable|string|max:255',
            'home_intro_title' => 'nullable|string|max:255',
            'home_intro_content' => 'nullable|string',
            'about_content' => 'nullable|string',
            'join_benefits' => 'nullable|string',
            'contract_alert_days' => 'required|integer|min:1|max:30',
            'contract_max_assignments' => 'required|integer|min:1|max:50',
            'notification_enabled' => 'boolean',
        ]);

        // Handle logo upload
        if ($request->hasFile('company_logo')) {
            // Delete old logo
            $oldLogo = Setting::get('company_logo');
            if ($oldLogo && Storage::disk('public')->exists($oldLogo)) {
                Storage::disk('public')->delete($oldLogo);
            }

            // Upload new logo
            $path = $request->file('company_logo')->store('logos', 'public');
            $validated['company_logo'] = $path;
        }

        // Update each setting
        foreach ($validated as $key => $value) {
            if ($key === 'company_logo' && !$request->hasFile('company_logo')) {
                continue; // Skip if no new logo uploaded
            }

            Setting::updateOrCreate(
                ['key' => $key],
                ['value' => $value]
            );
        }

        // Clear settings cache
        Cache::flush();

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Settings updated successfully.',
                'reload' => true
            ]);
        }

        return redirect()->back()
            ->with('success', 'Settings updated successfully.');
    }
}

