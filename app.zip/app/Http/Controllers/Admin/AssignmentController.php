<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Assignment;
use App\Models\Contract;
use App\Models\Employee;
use Illuminate\Http\Request;
use Carbon\Carbon;

class AssignmentController extends Controller
{
    /**
     * Display assignment listing
     */
    public function index(Request $request)
    {
        $query = Assignment::with(['contract.patient', 'contract.service', 'employee']);

        // Filter by status
        if ($request->filled('status')) {
            if ($request->status === 'active') {
                $query->active();
            } elseif ($request->status === 'inactive') {
                $query->inactive();
            }
        }

        // Filter by contract
        if ($request->filled('contract_id')) {
            $query->where('contract_id', $request->contract_id);
        }

        // Filter by employee
        if ($request->filled('employee_id')) {
            $query->where('employee_id', $request->employee_id);
        }

        $assignments = $query->latest()->paginate(20);

        $contracts = Contract::whereIn('status', ['not_assigned', 'active', 'closing_soon'])
            ->with('patient')
            ->get();
        
        $employees = Employee::active()->get();

        return view('admin.assignments.index', compact('assignments', 'contracts', 'employees'));
    }

    /**
     * Show create form
     */
    public function create(Request $request)
    {
        $contractId = $request->get('contract_id');
        
        $contracts = Contract::whereIn('status', ['not_assigned', 'active', 'closing_soon'])
            ->with('patient')
            ->get();
        
        $employees = Employee::active()->get();

        return view('admin.assignments.create', compact('contracts', 'employees', 'contractId'));
    }

    /**
     * Store new assignment
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'contract_id' => 'required|exists:contracts,id',
            'employee_id' => 'required|exists:employees,id',
            'start_date' => 'required|date',
            'end_date' => 'nullable|date|after:start_date',
            'is_emergency_replacement' => 'boolean',
            'notes' => 'nullable|string',
        ]);

        $validated['is_emergency_replacement'] = $request->has('is_emergency_replacement');
        $validated['is_active'] = true;

        // Check if employee is active
        $employee = Employee::find($validated['employee_id']);
        if ($employee->status !== 'active') {
            return redirect()->back()
                ->withInput()
                ->with('error', 'Cannot assign an inactive employee.');
        }

        // Check if employee has valid payment (if payment system is enabled)
        if (config('services.razorpay.employee_payment_enabled') && !$employee->hasValidPayment()) {
            if ($request->wantsJson() || $request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Employee payment has expired. Please renew before assigning.'
                ], 422);
            }
            return redirect()->back()
                ->withInput()
                ->with('error', 'Employee payment has expired. Please renew before assigning.');
        }

        // Deactivate previous assignment for this contract if exists
        Assignment::where('contract_id', $validated['contract_id'])
            ->where('is_active', true)
            ->update(['is_active' => false, 'end_date' => Carbon::now()]);

        $assignment = Assignment::create($validated);

        // Update contract status
        $contract = Contract::find($validated['contract_id']);
        $contract->updateStatus();

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Assignment created successfully.',
                'redirect' => route('admin.assignments.show', $assignment)
            ]);
        }

        return redirect()->route('admin.assignments.show', $assignment)
            ->with('success', 'Assignment created successfully.');
    }

    /**
     * Show assignment details
     */
    public function show(Assignment $assignment)
    {
        $assignment->load(['contract.patient', 'contract.service', 'employee']);

        return view('admin.assignments.show', compact('assignment'));
    }

    /**
     * Show edit form
     */
    public function edit(Assignment $assignment)
    {
        $employees = Employee::active()->get();

        return view('admin.assignments.edit', compact('assignment', 'employees'));
    }

    /**
     * Update assignment
     */
    public function update(Request $request, Assignment $assignment)
    {
        $validated = $request->validate([
            'employee_id' => 'required|exists:employees,id',
            'start_date' => 'required|date',
            'end_date' => 'nullable|date|after:start_date',
            'is_active' => 'boolean',
            'notes' => 'nullable|string',
        ]);

        $validated['is_active'] = $request->has('is_active');

        $assignment->update($validated);

        // Update contract status
        $assignment->contract->updateStatus();

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Assignment updated successfully.',
                'redirect' => route('admin.assignments.show', $assignment)
            ]);
        }

        return redirect()->route('admin.assignments.show', $assignment)
            ->with('success', 'Assignment updated successfully.');
    }

    /**
     * Emergency replacement
     */
    public function emergencyReplace(Request $request, Assignment $assignment)
    {
        $validated = $request->validate([
            'employee_id' => 'required|exists:employees,id',
            'notes' => 'nullable|string',
        ]);

        // Deactivate current assignment
        $assignment->update([
            'is_active' => false,
            'end_date' => Carbon::now(),
        ]);

        // Create new emergency assignment
        $newAssignment = Assignment::create([
            'contract_id' => $assignment->contract_id,
            'employee_id' => $validated['employee_id'],
            'start_date' => Carbon::now(),
            'is_emergency_replacement' => true,
            'is_active' => true,
            'notes' => $validated['notes'] ?? 'Emergency replacement',
        ]);

        return redirect()->route('admin.assignments.show', $newAssignment)
            ->with('success', 'Emergency replacement completed successfully.');
    }

    /**
     * Delete assignment
     */
    public function destroy(Assignment $assignment)
    {
        $contractId = $assignment->contract_id;
        
        $assignment->delete();

        // Update contract status
        $contract = Contract::find($contractId);
        $contract->updateStatus();

        if (request()->wantsJson() || request()->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Assignment deleted successfully.',
                'redirect' => route('admin.assignments.index')
            ]);
        }

        return redirect()->route('admin.assignments.index')
            ->with('success', 'Assignment deleted successfully.');
    }
}

