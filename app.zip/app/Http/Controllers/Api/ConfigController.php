<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Config;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ConfigController extends Controller
{
    public function showOtpConfig(): JsonResponse
    {
        return response()->json([
            'otp_phone_number' => Config::getValue('otp_phone_number', ''),
        ]);
    }

    public function updateOtpConfig(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'otp_phone_number' => 'required|string|max:20',
        ]);

        Config::setValue('otp_phone_number', $validated['otp_phone_number']);

        return response()->json([
            'success' => true,
            'message' => 'OTP configuration updated successfully.',
        ]);
    }
}
