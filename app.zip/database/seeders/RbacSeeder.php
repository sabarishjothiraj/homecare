<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class RbacSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $roles = [
            ['name' => 'Super Admin', 'slug' => 'super_admin', 'description' => 'Full platform access'],
            ['name' => 'Admin', 'slug' => 'admin', 'description' => 'Restricted administrative access'],
        ];

        foreach ($roles as $roleData) {
            Role::updateOrCreate(
                ['slug' => $roleData['slug']],
                [
                    'name' => $roleData['name'],
                    'description' => $roleData['description'],
                    'is_active' => true,
                ]
            );
        }

        $permissions = [
            'roles.create',
            'roles.read',
            'roles.update',
            'roles.delete',
            'permissions.assign',
            'users.manage',
            'otp.config.update',
        ];

        foreach ($permissions as $permissionSlug) {
            Permission::updateOrCreate(
                ['slug' => $permissionSlug],
                [
                    'name' => Str::of($permissionSlug)->replace('.', ' ')->title()->toString(),
                    'module' => Str::before($permissionSlug, '.'),
                    'is_active' => true,
                ]
            );
        }

        $superAdminRole = Role::where('slug', 'super_admin')->first();

        if ($superAdminRole) {
            $permissionIds = Permission::pluck('id')->all();
            $superAdminRole->permissions()->sync($permissionIds);
        }
    }
}
